import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const {JSDOM}=require(process.env.JSDOM_PATH||'../../../caregiver_mermaid/node_modules/jsdom');
const base=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const work=path.join(base,'source/dist/experiments/workbench-compare');
const appPath=path.join(work,'app.mjs');
const modules=await Promise.all(['design-choices','session','catalog','host-actions'].map(name=>import(path.join(work,name+'.mjs'))));
const {catalog}=modules[2];

// The actual app/module code runs unchanged except ESM imports are supplied through
// real exports and test-only access is appended. JSDOM does not load any resources.
// Geometry is explicitly synthetic: these are controlled behavior tests, not UI QA.
function harness(versionId='original',route='summary'){
 const dom=new JSDOM(fs.readFileSync(path.join(work,'index.html'),'utf8'),{url:'https://comparison.invalid/experiments/workbench-compare/',runScripts:'outside-only'});
 const w=dom.window;Object.assign(w,...modules);w.confirm=()=>true;
 // Browsers retain iframe WindowProxy identity across navigation; JSDOM replaces
 // the underlying Window. This adapter preserves only that platform invariant.
 const frameWindows=new WeakMap(),nativeWindow=Object.getOwnPropertyDescriptor(w.HTMLIFrameElement.prototype,'contentWindow').get;
 Object.defineProperty(w.HTMLIFrameElement.prototype,'contentWindow',{get(){
  if(!frameWindows.has(this)){const frame=this;frameWindows.set(frame,new Proxy({}, {get:(_,key)=>nativeWindow.call(frame)?.[key],set:(_,key,value)=>{nativeWindow.call(frame)[key]=value;return true;}}));}
  return frameWindows.get(this);
 }});
 const src=fs.readFileSync(appPath,'utf8').replace(/^import .*;\n/gm,'');
 new vm.Script(src+'\nglobalThis.__testApi={sessions,present,replacePair};').runInContext(dom.getInternalVMContext());
 w.document.getElementById('route').value=route;
 w.document.getElementById('left-version').value=versionId;
 w.__testApi.replacePair();
 const session=w.__testApi.sessions.get('left'),frame=session.frame,cw=frame.contentWindow;
 Object.defineProperty(cw.HTMLElement.prototype,'inert',{configurable:true,get(){return this.hasAttribute('inert');},set(value){this.toggleAttribute('inert',!!value);}});
 const docId='a'.repeat(32);let sequence=0;
 const marker=(routeValue)=>({protocol:'historical-comparison-observation-v2',side:'left',variant:versionId,epoch:frame.name.split(':').at(-1),mainSha256:session.version.mainSha256,caseKey:session.caseKey,caseId:session.selectedCase.caseId,caseSha256:session.selectedCase.caseSha256,documentId:docId,sequence:++sequence,route:routeValue,edited:false});
 const cfg={route,variant:versionId,main:session.version.main,mainSha256:session.version.mainSha256,caseKey:session.caseKey,caseId:session.selectedCase.caseId,caseSha256:session.selectedCase.caseSha256};
 cw.__HISTORICAL_COMPARE_CONFIG__=Object.freeze(cfg);
 function surface(mode='overview',attrs=''){
  const witnesses=mode==='overview'?'<section data-testid="child-growth-scroll"><div data-testid="child-overview-content">小晴的成長概覽</div></section>':mode==='archive'?'<section data-testid="child-growth-scroll"><div data-testid="child-archive-content">小晴的成長封存</div></section>':mode==='logo'?'<div>育伴港</div>':mode==='error'?'<div>Something went wrong</div>':'<div>正在載入…</div>';
  cw.document.open();cw.document.write(`<!doctype html><html><head></head><body><div id="root"><div data-testid="frontend-preview-ready" data-startup-state="ready" data-startup-data="ready" aria-busy="false" ${attrs}>${witnesses}</div></div></body></html>`);cw.document.close();
  for(const el of cw.document.querySelectorAll('[data-testid]'))el.getClientRects=()=>[{width:320,height:200}];
 }
 function observe(routeValue='/summary',load=false){
  cw.history.replaceState(null,'',routeValue);const m=marker(routeValue);cw.__HISTORICAL_COMPARE_OBSERVATION__=m;
  if(load)frame.dispatchEvent(new w.Event('load'));
  else w.dispatchEvent(new w.MessageEvent('message',{source:cw,origin:w.location.origin,data:m}));
  return m;
 }
 function present(){return w.__testApi.present('left');}
 function result(){const context=present();return {context,disabled:w.document.getElementById('left-pick').disabled,inert:frame.inert,armed:session.pickArmed,locked:session.pickLocked};}
 return {w,session,frame,cw,surface,observe,present,result,close:()=>dom.window.close()};
}
for(const {id} of catalog.versions){
 test(`${id}: logo-only initial Summary cannot be picked or interacted with`,()=>{
  const h=harness(id);try{h.surface('logo');h.observe('/summary',true);const r=h.result();assert.equal(r.disabled,true);assert.equal(r.inert,true);assert.equal(r.armed,false);}finally{h.close();}
 });
 test(`${id}: bootstrap Summary → Home → Summary arms only when Overview is visible`,()=>{
  const h=harness(id);try{
   h.surface('logo');h.observe('/summary',true);h.observe('/');assert.equal(h.result().locked,false);
   h.observe('/summary');assert.equal(h.result().disabled,true);
   h.surface('overview');const r=h.result();assert.equal(r.armed,true);assert.equal(r.locked,false);assert.equal(r.disabled,false);assert.equal(r.inert,false);
  }finally{h.close();}
 });
 test(`${id}: armed Summary Archive remains selectable, real post-arm page switch stays locked`,()=>{
  const h=harness(id);try{
   h.surface('overview');h.observe('/summary',true);assert.equal(h.result().disabled,false);
   h.surface('archive');h.observe('/summary?tab=archive');assert.equal(h.result().disabled,false);
   h.observe('/');assert.equal(h.result().locked,true);
   h.observe('/summary');assert.equal(h.result().disabled,true);assert.equal(h.result().locked,true);
  }finally{h.close();}
 });
}
test('initial Overview witnesses must be visible',()=>{
 for(const attr of ['hidden','inert','aria-hidden="true"','style="display:none"','style="visibility:hidden"','style="opacity:0"']){
  const h=harness();try{h.surface('overview',attr);h.observe('/summary',true);assert.equal(h.result().disabled,true,attr);assert.equal(h.result().armed,false,attr);}finally{h.close();}
 }
});
test('armed Archive still requires ready data, idle state, visible shell and nonerror content',()=>{
 for(const mutation of ['busy','data','startup','shell','error','blank']){
  const h=harness();try{h.surface();h.observe('/summary',true);assert.equal(h.result().disabled,false);h.surface('archive');
   const ready=h.cw.document.querySelector('[data-testid="frontend-preview-ready"]');
   if(mutation==='busy')ready.setAttribute('aria-busy','true');
   if(mutation==='data')ready.setAttribute('data-startup-data','loading');
   if(mutation==='startup')ready.setAttribute('data-startup-state','loading');
   if(mutation==='shell')h.cw.document.querySelector('[data-testid="child-growth-scroll"]').hidden=true;
   if(mutation==='error')ready.querySelector('[data-testid="child-growth-scroll"]').textContent='Something went wrong';
   if(mutation==='blank')ready.querySelector('[data-testid="child-growth-scroll"]').textContent='';
   assert.equal(h.result().disabled,true,mutation);
  }finally{h.close();}
 }
});
test('Summary mismatched marker removes authority, and document reload cannot retain it',()=>{
 const h=harness();try{
  h.surface();h.observe('/summary',true);assert.equal(h.result().disabled,false);
  const saved=h.cw.__HISTORICAL_COMPARE_OBSERVATION__;
  h.cw.__HISTORICAL_COMPARE_OBSERVATION__={...saved,mainSha256:'0'.repeat(64)};
  assert.equal(h.result().disabled,true);
  h.cw.__HISTORICAL_COMPARE_OBSERVATION__={...saved,documentId:'b'.repeat(32),sequence:1};
  h.frame.dispatchEvent(new h.w.Event('load'));assert.equal(h.result().locked,true);assert.equal(h.result().disabled,true);
 }finally{h.close();}
});
test('Summary choice click records only the pinned design identity and deduplicates Archive',()=>{
 const h=harness('care');try{
  h.surface();h.observe('/summary',true);assert.equal(h.result().disabled,false);
  h.w.document.getElementById('left-pick').click();
  assert.equal(h.w.document.getElementById('choice-count').textContent,'1');
  const text=h.w.document.getElementById('choice-list').textContent;
  assert.match(text,/摘要/);assert.match(text,/6631c82a994b522c5d56dc842d23ce9264f0acbb65f0cf03e9f92e8a169d833f/);assert.doesNotMatch(text,/小晴/);
  h.surface('archive');assert.equal(h.result().disabled,false);h.w.document.getElementById('left-pick').click();assert.equal(h.w.document.getElementById('choice-count').textContent,'1');
 }finally{h.close();}
});
test('existing Growth readiness gate still requires both surfaces after arming',()=>{
 const h=harness('original','growth');try{
  h.surface('logo');h.observe('/growth',true);assert.equal(h.result().disabled,true);
  const ready=h.cw.document.querySelector('[data-testid="frontend-preview-ready"]');
  ready.innerHTML='<section data-testid="growth-scroll">成長記錄</section><nav data-testid="growth-tabs-toolbar">成長分類</nav>';
  for(const el of ready.children)el.getClientRects=()=>[{width:320,height:100}];
  assert.equal(h.result().disabled,false);
  ready.querySelector('[data-testid="growth-tabs-toolbar"]').hidden=true;assert.equal(h.result().disabled,true);
 }finally{h.close();}
});

test('Summary initial arming requires ready, ready data and nonbusy startup',()=>{
 for(const [attribute,value] of [['data-startup-state','loading'],['data-startup-data','loading'],['aria-busy','true']]){
  const h=harness();try{h.surface();h.cw.document.querySelector('[data-testid="frontend-preview-ready"]').setAttribute(attribute,value);h.observe('/summary',true);const r=h.result();assert.equal(r.armed,false,attribute);assert.equal(r.disabled,true,attribute);assert.equal(r.inert,true,attribute);}finally{h.close();}
 }
});
test('Summary mismatched identity cannot arm initially',()=>{
 const h=harness();try{h.surface();h.observe('/summary');
  h.cw.__HISTORICAL_COMPARE_OBSERVATION__={...h.cw.__HISTORICAL_COMPARE_OBSERVATION__,mainSha256:'0'.repeat(64)};
  h.frame.dispatchEvent(new h.w.Event('load'));
  const r=h.result();assert.equal(r.armed,false);assert.equal(r.disabled,true);assert.equal(r.inert,true);
 }finally{h.close();}
});

test('real host clicks across Summary aliases keep one choice and preserve its first source',()=>{
 const h=harness('care');try{
  h.surface();h.observe('/summary/',true);assert.equal(h.result().disabled,false);
  h.w.document.getElementById('left-pick').click();
  assert.equal(h.w.document.getElementById('choice-count').textContent,'1');
  const firstText=h.w.document.getElementById('choice-list').textContent;
  for(const alias of ['/summary','/summary.html','/(dashboard)/summary','/(dashboard)/summary/','/(dashboard)/summary.html']){
   h.observe(alias);assert.equal(h.result().disabled,false,alias);
   h.w.document.getElementById('left-pick').click();
   assert.equal(h.w.document.getElementById('choice-count').textContent,'1',alias);
   assert.equal(h.w.document.getElementById('choice-list').textContent,firstText);
   assert.equal(h.w.document.getElementById('choice-status').textContent,'這個設計已在清單中。');
  }
  h.w.document.querySelector('#choice-list button').click();
  assert.equal(h.w.document.getElementById('choice-count').textContent,'0');
  h.w.document.getElementById('left-pick').click();
  assert.equal(h.w.document.getElementById('choice-count').textContent,'1');
 }finally{h.close();}
});
