import test from 'node:test';
import assert from 'node:assert/strict';
import {catalog} from '../source/dist/experiments/workbench-compare/catalog.mjs';
import {createChoiceList,resolveChoice,TASK_PARTS} from '../source/dist/experiments/workbench-compare/design-choices.mjs';

const version=id=>catalog.versions.find(v=>v.id===id);
const context=(actualRoute='/summary',id='care')=>({version:version(id),actualRoute,observation:{sourceIdentityObserved:true,route:actualRoute},rendered:true,visible:true});
const summaryAliases=['/summary','/summary/','/summary.html','/(dashboard)/summary','/(dashboard)/summary/','/(dashboard)/summary.html'];

// Break caught: literal aliases become distinct selection keys instead of one design.
test('six Summary aliases deduplicate while retaining the first observed path',()=>{
 const list=createChoiceList();
 const order=['/summary/',...summaryAliases.filter(p=>p!=='/summary/')];
 assert.equal(list.add(context(order[0])).status,'added');
 const first=list.items()[0];
 for(const alias of order.slice(1)){
  const result=list.add(context(alias));
  assert.equal(result.status,'duplicate',alias);
  assert.equal(result.choice,first,'must preserve first source object');
 }
 assert.equal(list.items().length,1);
 assert.equal(first.actualPath,'/summary/');
 assert.equal(first.id,'care:/summary:page');
 assert.equal(first.route,'summary');
 assert.equal(first.mainSha256,'6631c82a994b522c5d56dc842d23ce9264f0acbb65f0cf03e9f92e8a169d833f');
 const summary=list.summary();
 const exported=JSON.parse(summary.slice(summary.indexOf('{\n  "schema"')));
 assert.equal(exported.selections.length,1,'copied JSON must contain only the deduplicated choice');
 assert.equal(exported.selections[0].actualPath,'/summary/');
 assert.equal(exported.selections[0].mainSha256,first.mainSha256);
});

test('all known homepage aliases share the existing canonical homepage ID',()=>{
 const list=createChoiceList();
 for(const [i,p] of ['/','/index','/index/','/index.html'].entries())assert.equal(list.add(context(p)).status,i?'duplicate':'added',p);
 assert.equal(list.items().length,1);
 assert.equal(list.items()[0].id,'care:/:page');
});

test('normalization applies to admitted pages rather than a Summary-only exception',()=>{
 for(const page of ['tasks','care','chat','growth','memory','guide','family','profile','sources','contact','history','settings','more','login']){
  const list=createChoiceList();
  const aliases=['/'+page,'/'+page+'/','/'+page+'.html','/(dashboard)/'+page,'/(dashboard)/'+page+'/','/(dashboard)/'+page+'.html'];
  for(const [i,p] of aliases.entries())assert.equal(list.add(context(p)).status,i?'duplicate':'added',p);
  assert.equal(list.items().length,1,page);
 }
});

// Break caught: an overbroad dedupe key drops meaningful design dimensions.
test('distinct variants, semantic pages and Tasks parts remain separate',()=>{
 const list=createChoiceList();
 for(const [p,id,part] of [
  ['/summary','care','page'],['/summary','original','page'],['/tasks','care','page'],
  ...TASK_PARTS.map(p=>['/tasks','care',p.id]),
 ])assert.equal(list.add(context(p,id),part).status,'added');
 assert.equal(list.items().length,7);
 assert.equal(new Set(list.items().map(c=>c.id)).size,7);
 for(const part of TASK_PARTS)assert.equal(list.add(context('/(dashboard)/tasks.html'),part.id).status,'duplicate');
 assert.equal(list.items().length,7);
});

test('Overview and Archive query variants are the same whole-page design without exporting queries',()=>{
 const list=createChoiceList();
 assert.equal(list.add(context('/summary/?previewScenario=ready')).status,'added');
 assert.equal(list.add(context('/summary?tab=archive&token=synthetic-secret#report')).status,'duplicate');
 assert.equal(list.items().length,1);
 assert.doesNotMatch(list.summary(),/synthetic-secret|previewScenario|tab=archive|#report/);
});

test('canonical legacy IDs remain removable and re-add preserves the new first path',()=>{
 const list=createChoiceList();
 list.add(context('/summary.html'));
 assert.equal(list.remove('care:/summary:page'),true);
 assert.equal(list.items().length,0);
 assert.equal(list.remove('care:/summary:page'),false);
 assert.equal(list.add(context('/(dashboard)/summary/')).status,'added');
 assert.equal(list.items()[0].actualPath,'/(dashboard)/summary/');
 assert.equal(list.add(context('/summary')).status,'duplicate');
 assert.equal(list.items().length,1);
});

// Break caught: canonicalizing authority as well as identity admits stale markers.
test('observation route must still match exactly, not merely canonicalize equally',()=>{
 for(const p of summaryAliases){
  const ctx=context(p);ctx.observation.route=p==='/summary'?'/summary/':'/summary';
  assert.equal(resolveChoice(ctx),null,p);
  assert.equal(createChoiceList().add(ctx).status,'unavailable',p);
 }
});

test('unready, hidden, unobserved, wrong pinned source and invalid parts stay rejected',()=>{
 for(const change of [
  c=>{c.rendered=false;},c=>{c.visible=false;},c=>{c.observation=null;},
  c=>{c.observation.sourceIdentityObserved=false;},c=>{c.version={...c.version,mainSha256:'0'.repeat(64)};},
  c=>{c.version={...c.version,sourceReference:'unverified'};},c=>{c.version={...c.version,main:'other.js'};},
 ]){const c=context('/summary/');change(c);assert.equal(resolveChoice(c),null);}
 for(const p of ['header-actions','unknown','__proto__'])assert.equal(resolveChoice(context(),p),null,p);
});

test('unknown, malformed, external and view-only paths are not admitted by canonical IDs',()=>{
 for(const p of ['/summary//','/summary/other','/not-a-route','/admin','/photos','//evil.invalid/summary','https://evil.invalid/summary','/summary\\x','/%E0%A4%A','/%2F%2Fevil.invalid','/(dashboard)/summary//']){
  assert.equal(resolveChoice(context(p)),null,p);
 }
});
