from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/'SOURCE-MANIFEST.json').read_text())
expected={x['path']:x for x in m['files']}
assert len(expected)==len(m['files'])==601
actual={}
for p in (r/'source').rglob('*'):
 assert not p.is_symlink()
 if p.is_dir():continue
 assert p.is_file()
 b=p.read_bytes();n=p.relative_to(r).as_posix();actual[n]={'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert actual==expected
print('PASS: all 601 public-safe source files match the exact transport manifest')
