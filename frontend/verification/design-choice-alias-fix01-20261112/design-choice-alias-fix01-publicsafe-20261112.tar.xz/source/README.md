# Snapshot40 synthetic preview candidate

Immutable snapshot39 / Site90 plus the reviewed preparation exit-recovery patch.573 frozen inputs;24 scope files comprise8 products and16 test-evidence files. Only8 product inputs changed;565 remain byte-exact, retaining avatar, attachment and master model-settings changes.

One export and every emitted first-party source/PNG/changed-module/Router40 provenance gate passed. All9 preview boundary files, including notice fix1, are byte-identical to39. Only the unique terminal source-map comment is removed; source maps stay private.

Fresh full artifact validator passed. Author final37/37 and focused8root0diagnostics are carried, not rerun. Full typecheck remains killed137/not passed; broader legacy-consumer tests were not all passing or individually established baseline. Prior GUI evidence is not a fresh40 full-matrix pass, especially for shared recovery/navigation guards.

Bounded40 preparation-recovery GUI is pending. No icons, animation changes, observer, real model/data/backend, PR mutation or publication. Precise identity and limits are in verification/snapshot40-public-summary.json, a public summary rather than private raw-receipt bytes.
