import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const here=path.resolve(new URL('..',import.meta.url).pathname);
const dist=path.join(here,'dist');
const manifest=JSON.parse(await fs.readFile(path.join(here,'verification/adapter-manifest.json'),'utf8'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const text=async p=>await fs.readFile(path.join(dist,p),'utf8');
let payloadChecks=0,assetChecks=0,baselineChecks=0,dispatchChecks=0;
for(const row of manifest.payloads){
 const raw=await text(row.payload);
 assert.equal(sha(Buffer.from(raw)),row.payloadSha256);
 let html;vm.runInNewContext(raw,{document:{write(value){assert.equal(html,undefined);html=value;}}});
 assert.equal(sha(Buffer.from(html)),row.preparedHtmlSha256);
 const reverted=row.version==='original'?html:html.replace('src="/experiments/preview-fixture.js"','src="/__preview/preview-fixture.js"');
 assert.equal(sha(Buffer.from(reverted)),row.sourceSha256);
 assert(html.includes("connect-src 'none'"));
 assert(html.indexOf('Content-Security-Policy')<html.indexOf('/_expo/static/js/web/'));
 if(row.version!=='original'){
  assert.match(html,/<html\b[^>]*\blang="zh-Hant"/);
  assert(!/maximum-scale|user-scalable=no/.test(html));
  assert(html.indexOf('/experiments/preview-fixture.js')<html.indexOf('/_expo/static/js/web/'));
  assert(!html.includes('/preview/synthetic-ports.js'));
  assert(!html.includes('src="/__preview/preview-fixture.js"'));
 }
 payloadChecks++;
}
for(const row of manifest.unchangedExperimentalAssets){assert.equal(sha(await fs.readFile(path.join(dist,row.path))),row.sha256);assetChecks++;}
for(const [file,hash] of Object.entries(manifest.baselineNonHtml)){assert.equal(sha(await fs.readFile(path.join(dist,file))),hash);baselineChecks++;}
assert.equal(sha(await fs.readFile(path.join(dist,'experiments/preview-fixture.js'))),manifest.fixtureSha256);
const extension=JSON.parse(await fs.readFile(path.join(here,'verification/extension-baseline.json'),'utf8'));
let preservedBaseline=0;
for (const [file,hash] of Object.entries(extension.baselineDist)) {
 if (!extension.allowedModifiedExisting.includes(file)) {assert.equal(sha(await fs.readFile(path.join(dist,file))),hash,'baseline changed '+file);preservedBaseline++;}
}
const dispatch=await text('experiments/dispatch.js');
function invoke(url,saved){
 const store=new Map(saved?[['yuban.frontend-comparison.v1',saved]]:[]);let written=[],replaced;
 const context={URL,Set,location:new URL(url),sessionStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)},history:{state:null,replaceState:(state,unused,next)=>replaced=next},window:{},document:{write:s=>written.push(s)}};
 vm.runInNewContext(dispatch,context);
 return {selected:context.window.__YU_COMPARISON__,written,store,replaced};
}
for(const route of manifest.routeKeys)for(const version of ['original','harbour','care','journal']){
 const href='https://preview.example.invalid/'+(route==='index'?'':route+'.html');
 const item=invoke(href,version==='original'?undefined:version);
 const expected=route;
 assert.equal(item.selected.version,version);assert.equal(item.selected.route,expected);
 assert.equal(item.written[0],`<script src="/experiments/payload/${version}/${expected}.js"></script>`);dispatchChecks++;
}
for(const version of ['harbour','care','journal']){
 const chosen=invoke('https://preview.example.invalid/?experiment='+version);
 assert.equal(chosen.selected.version,version);assert.equal(chosen.selected.route,'index');
 assert.equal(chosen.store.get('yuban.frontend-comparison.v1'),version);
 const reload=invoke('https://preview.example.invalid/chat',chosen.store.get('yuban.frontend-comparison.v1'));assert.equal(reload.selected.version,version);
 const reset=invoke('https://preview.example.invalid/?experiment=original',version);assert.equal(reset.selected.version,'original');assert.equal(reset.store.size,0);dispatchChecks+=3;
}
assert.equal(invoke('https://preview.example.invalid/').selected.version,'original');
assert.equal(invoke('https://preview.example.invalid/?experiment=https://evil.invalid').selected.version,'original');
assert.equal(invoke('https://preview.example.invalid/chat?experiment=care&q=%E5%B0%8F%E6%99%B4#read').replaced,'/chat?q=%E5%B0%8F%E6%99%B4#read');dispatchChecks+=3;
for(const version of ['original','harbour','care','journal']) for(const route of ['/not-a-route','/%E0%A4%A','/%2F%2Fevil.invalid','/%3Cscript%3E','/../bad']) {
 const selected=invoke('https://preview.example.invalid'+route,version==='original'?undefined:version);
 assert.equal(selected.selected.route,'+not-found');assert.equal(selected.written[0],`<script src="/experiments/payload/${version}/+not-found.js"></script>`);dispatchChecks++;
}
for(const requested of ['harbour','care','journal']) {
 let written=[],context={URL,Set,location:new URL('https://preview.example.invalid/?experiment='+requested),sessionStorage:{getItem(){throw Error('disabled');}},history:{state:null,replaceState(){}},window:{},document:{write:s=>written.push(s)}};
 vm.runInNewContext(dispatch,context);assert.equal(context.window.__YU_COMPARISON__.version,requested);assert.equal(written.length,1);dispatchChecks++;
}
let localReferences=0;
for(const row of manifest.payloads){let html;vm.runInNewContext(await text(row.payload),{document:{write:value=>{html=value;}}});
 for(const match of html.matchAll(/(?:src|href)="([^"]+)"/g)) {
  const raw=match[1];if(raw.startsWith('data:')||raw.startsWith('#'))continue;
  const url=new URL(raw,'https://preview.example.invalid/'+row.routeFile);assert.equal(url.origin,'https://preview.example.invalid','external HTML reference '+raw);
  const relative=decodeURIComponent(url.pathname).replace(/^\/+/,''),candidates=[relative,relative+'.html',path.join(relative,'index.html')];
  let found=false;for(const file of candidates){try{if((await fs.stat(path.join(dist,file))).isFile()){found=true;break;}}catch{}}
  assert(found,'missing local reference '+raw);localReferences++;
 }
}
assert.equal(await text('experiments/index.html'),await text('experiments.html'));
const landing=await text('experiments/index.html');for(const choice of ['harbour','care','journal'])assert(landing.includes('href="/?experiment='+choice+'" target="_blank" rel="noopener"'));
assert(landing.includes("default-src 'none'"));
async function walk(dir){let all=[];for(const e of await fs.readdir(dir,{withFileTypes:true})){assert(!e.isSymbolicLink());let p=path.join(dir,e.name);if(e.isDirectory())all.push(...await walk(p));else all.push(p);}return all;}
const all=await walk(dist),forbidden=[],preservedBaselineMapReferences=[];
const currentAssets=new Set(manifest.unchangedExperimentalAssets.map(row=>row.path));
for(const file of all){const rel=path.relative(dist,file);if(/(?:^|\/)(?:\.git|\.env|verification|evidence)(?:\/|$)|\.(?:map|pem|key|zip|tgz|log)$/.test(rel))forbidden.push(rel);if(rel.includes('/node_modules/') && !(rel.startsWith('assets/') && /\.(png|ttf)$/.test(rel)))forbidden.push(rel);const data=await fs.readFile(file);if(file.endsWith('.js')&&data.includes(Buffer.from('sourceMappingURL='))){assert(!currentAssets.has(rel),'new candidate map reference '+rel);assert.equal(sha(data),extension.baselineDist[rel],'map reference must be unchanged baseline only');preservedBaselineMapReferences.push({path:rel,sha256:sha(data),reason:'Existing v92 artifact comment kept byte-identical; no .map files copied or present'});}if(/\.(?:html|js|json|css)$/.test(file))assert(!/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|AIza[0-9A-Za-z_-]{35}|gh[pousr]_[A-Za-z0-9]{32,}|sk-(?:proj-)?[A-Za-z0-9_-]{35,}/.test(data.toString()),'Credential-like pattern: '+rel);}
assert.deepEqual(forbidden,[]);
const report={status:'pass',preservedBaselineMapReferences,newCandidateMapReferences:0,publicMapFiles:0,payloadChecks,assetChecks,baselineChecks,preservedBaseline,dispatchChecks,localReferences,files:all.length,bytes:(await Promise.all(all.map(async f=>(await fs.stat(f)).size))).reduce((a,b)=>a+b,0),exactHtmlRestoration:true,experimentalBundlesUnchanged:true,fixtureUnchanged:true,unknownNavigation:'routes constrained to frozen route set; no URL-origin or route injection',network:'CSP connect-src none; same reviewed fixture and deny APIs; payload delivery only same-origin script',browser:'not run in this preparer; parent-owned exact staged cloud-browser acceptance remains required'};
await fs.writeFile(path.join(here,'verification/adapter-checks.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
