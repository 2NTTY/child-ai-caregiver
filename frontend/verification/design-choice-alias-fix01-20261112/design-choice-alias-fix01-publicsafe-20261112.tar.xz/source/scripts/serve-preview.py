from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit, unquote
ROOT=Path(__file__).resolve().parent.parent/'dist'
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT),**kwargs)
 def do_GET(self):
  path=unquote(urlsplit(self.path).path)
  if path.startswith('/api/'):
   self.send_error(405,'Synthetic preview does not serve an API');return
  p=ROOT/path.lstrip('/')
  if not p.exists() and not p.suffix and p.with_suffix('.html').is_file():self.path=path+'.html'
  super().do_GET()
 def do_POST(self):self.send_error(405,'Synthetic preview blocks network writes')
 def end_headers(self):
  self.send_header('Cache-Control','no-store')
  self.send_header('Permissions-Policy','camera=(), microphone=(), geolocation=(), display-capture=()')
  super().end_headers()
print('Static synthetic preview: http://127.0.0.1:8087/',flush=True)
ThreadingHTTPServer(('127.0.0.1',8087),Handler).serve_forever()
