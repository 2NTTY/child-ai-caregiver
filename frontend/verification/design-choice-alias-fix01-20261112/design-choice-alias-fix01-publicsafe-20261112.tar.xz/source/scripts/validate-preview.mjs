import assert from 'node:assert/strict';
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { join, dirname, resolve, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import vm from 'node:vm';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dist = join(root, 'dist');
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const files = dir => readdirSync(dir, { withFileTypes: true }).flatMap(entry => entry.isDirectory() ? files(join(dir, entry.name)) : [join(dir, entry.name)]);
const bundlePath = '_expo/static/js/web/index-bd76e37195c959192eab162f36438f50.js';
assert.equal(digest(readFileSync(join(dist, bundlePath))), '786f8608718d34dc7b005a9f1c088febd195bd98712ac682a7930a1f4e8a3a27');
const product = JSON.parse(readFileSync(join(root, 'preview-product-manifest.json'), 'utf8'));
assert.equal(product.frozenExport, 'frontend-snapshot40-publishable');
assert.equal(product.bundlePath, bundlePath);
assert.equal(product.bundleSha256, digest(readFileSync(join(dist, bundlePath))));
assert.equal(product.originalFileCount, 65, 'Frozen export artifact count');
assert.equal(product.originalHtmlCount, 36, 'Frozen export application HTML count');
assert.equal(Object.keys(product.originalFiles).length, product.originalFileCount);
for (const [path, hash] of Object.entries(product.originalFiles)) {
  if (!path.endsWith('.html')) assert.equal(digest(readFileSync(join(dist, path))), hash, 'Unmodified product asset: ' + path);
}
for (const [path, hash] of Object.entries(product.retainedPreviewFiles)) assert.equal(digest(readFileSync(join(dist, path))), hash, 'Unmodified v73 preview boundary: ' + path);
assert.equal(Object.keys(product.retainedPreviewFiles).length, 4, 'Unchanged viewport boundary files; notice38-fix1, safety38 and fixture increments explicitly approved');
assert.equal(Object.keys(product.approvedPreviewChanges).length, 1);
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].beforeSha256, '8bca937d7df8ab94362337d8811fe3f8d6f1208ef68112f41439b398c31e7216');
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].sha256, '9d507a2d46b1da27f5ec64e242e53cab2d5748c2bf6f4e054e77c9b4f6c59e6f');
assert.equal(files(dist).length, 74, 'Frozen product plus retained preview files and two approved overlay scripts');
// Artifact-only notice layer fix; all remaining original38 dist bytes retain their hashes.
const noticeFixText = readFileSync(join(root,'scripts/approved-notice38-fix1.json'),'utf8');
assert.equal(digest(noticeFixText), '69eb87c11296601f95f58e1bb8b7f66081f6984f172b87ff8cb7801c028d1bd8');
const noticeFix=JSON.parse(noticeFixText);
assert.equal(product.approvedNoticeFix1.changesSha256,digest(noticeFixText));
assert.equal(noticeFix.path,'preview/notice.css');
assert.equal(noticeFix.before,'z-index:2147483000'); assert.equal(noticeFix.after,'z-index:9998');
const noticeCss=readFileSync(join(dist,noticeFix.path),'utf8');
assert.equal(digest(noticeCss),noticeFix.sha256); assert.equal(product.approvedNoticeFix1.sha256,noticeFix.sha256);
assert.equal(noticeCss.split(noticeFix.after).length,2); assert.ok(!noticeCss.includes(noticeFix.before));
assert.equal(digest(noticeCss.replace(noticeFix.after,noticeFix.before)),noticeFix.beforeSha256,'Exact one-property inverse preserves every previous notice byte');
assert.equal(product.approvedNoticeFix1.beforeSha256,noticeFix.beforeSha256);
assert.equal(noticeFix.modalProof.modalZIndex,9999); assert.equal(noticeFix.modalProof.noticeZIndex,9998);
assert.ok(noticeFix.modalProof.noticeZIndex<noticeFix.modalProof.modalZIndex);
// Snapshot38 artifact-only overlay: exact reviewed bytes and reversible HTML delta.
const overlayText = readFileSync(join(root, 'scripts/approved-overlay38-changes.json'), 'utf8');
assert.equal(digest(overlayText), '27477739a6cbf3825e9a9562cbc70e32a1d4abf8036ae3377d9ebf255ec0c2fe');
const overlay = JSON.parse(overlayText);
assert.equal(product.approvedArtifactOverlay38.changesSha256, digest(overlayText));
assert.deepEqual(product.approvedArtifactOverlay38.runtime, overlay.runtime);
assert.equal(product.approvedArtifactOverlay38.safetyWasModified, true);
assert.deepEqual(Object.keys(overlay.runtime).sort(), ['preview/attachment-fixture.js','preview/avatar-qa.js','preview/safety.js']);
for (const [path, hash] of Object.entries(overlay.runtime)) assert.equal(digest(readFileSync(join(dist,path))), hash, 'Exact approved38 overlay: '+path);
assert.equal(overlay.previousSafetySha256, 'be313eb816eafad94d719ea81464a778567ae61a0369f4ddf6f1cc2db848047e');
assert.equal(Object.keys(overlay.html).length, product.originalHtmlCount);
assert.equal(digest(readFileSync(join(dist,'qa-viewport.html'))), overlay.qaViewportSha256);
for (const [path, hashes] of Object.entries(overlay.html)) {
 const html=readFileSync(join(dist,path),'utf8'); assert.equal(digest(html),hashes.sha256);
 assert.equal(html.split(overlay.scriptPatch.after).length,2); assert.equal(html.split(overlay.mediaCspPatch.after).length,2);
 const inverse=html.replace(overlay.scriptPatch.after,overlay.scriptPatch.before).replace(overlay.mediaCspPatch.after,overlay.mediaCspPatch.before);
 assert.equal(digest(inverse),hashes.beforeSha256,'Only approved script/CSP delta: '+path);
 for(const term of overlay.requiredUnchangedCsp)assert.ok(html.includes(term),path+': '+term);
 const order=['/preview/synthetic-ports.js','/preview/attachment-fixture.js','/preview/avatar-qa.js','/preview/safety.js','/'+bundlePath];
 let previous=-1;for(const term of order){assert.equal(html.split('src="'+term+'"').length,2);const position=html.indexOf('src="'+term+'"');assert.ok(position>previous,path+': exact wrapper order');previous=position;}
 const csp=html.match(/http-equiv="Content-Security-Policy" content="([^"]+)"/)[1];
 assert.equal(csp.split(';').map(x=>x.trim()).find(x=>x.startsWith('media-src ')), 'media-src blob:');
}
const hosting = JSON.parse(readFileSync(join(root, '.openai/hosting.json'), 'utf8'));
assert.equal(hosting.project_id, 'appgprj_6ac1e7c965308191bc2c599951348a51');
assert.equal(hosting.static.directory, 'dist');
const htmlFiles = files(dist).filter(path => extname(path) === '.html');
assert.equal(htmlFiles.length, 37, 'Frozen export HTML count plus retained viewport');
for (const path of htmlFiles) {
  const html = readFileSync(path, 'utf8');
  assert.ok(html.includes("connect-src 'none'"), path + ': fail-closed CSP');
  for (const match of html.matchAll(/(?:src|href)="([^"]+)"/g)) {
    const target = match[1].split('?')[0];
    if (!target.startsWith('/') || target === '/') continue;
    const absolute = join(dist, target);
    assert.ok(existsSync(absolute) || existsSync(absolute + '.html'), path + ': unresolved ' + target);
  }
  if (path.endsWith('/qa-viewport.html')) continue;
  assert.ok(html.indexOf('Content-Security-Policy') < html.indexOf('<script'), path + ': CSP before scripts');
  assert.ok(html.indexOf('/preview/synthetic-ports.js') < html.indexOf('/' + bundlePath), path + ': fixture before product');
  assert.ok(html.includes('id="synthetic-preview-notice"'), path + ': visible notice');
  assert.ok(html.includes('非正式版'), path + ': honest boundary');
  assert.ok(!html.includes('qa-recovery-fixture') && !html.includes('navigation-meter') && !html.includes('/__fixture'), path + ': no legacy diagnostics');
}
for (const route of ['login','tasks','chat','growth','summary','profile','care','settings','more','photos','sources','contact','family','history','guide','memory']) assert.ok(existsSync(join(dist, route + '.html')), route + ': direct route');

const fixture = readFileSync(join(dist, 'preview/synthetic-ports.js'), 'utf8');
assert.equal(digest(fixture), '9d507a2d46b1da27f5ec64e242e53cab2d5748c2bf6f4e054e77c9b4f6c59e6f', 'Only approved public fixture; no QA-only 503 controls');
// Approved35 fixes the existing catalog error scenario: genuine503, never authoritative200-empty.
const quietChangeText = readFileSync(join(root, 'scripts/approved-quiet35-fixture-change.json'), 'utf8');
assert.equal(digest(quietChangeText), 'da57061bd22b51eefd2e5c4c1265d4eba29ec52f7b57ff97ac62f6f5ddc171bc');
const quietChange = JSON.parse(quietChangeText);
assert.equal(quietChange.file, 'dist/preview/synthetic-ports.js');
assert.equal(quietChange.sha256, digest(fixture));
assert.equal(fixture.split(quietChange.after).length, 2, 'Exactly one approved catalog error-mode expression');
const fixtureBeforeQuiet35 = fixture.replace(quietChange.after, quietChange.before);
assert.equal(digest(fixtureBeforeQuiet35), '66a0b4515e911ccc41cac8b1bf785b48790fdca885c5ab1ebd1fcc033258634f', 'Exact catalog inverse restores every immutable34 fixture byte');
assert.equal(quietChange.beforeSha256, digest(fixtureBeforeQuiet35));
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].quiet35BeforeSha256, digest(fixtureBeforeQuiet35));
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].quiet35ChangesSha256, digest(quietChangeText));
// Approved34 changes only child A's current-v4 preference display copy; every other fixture byte is exact.
const preferenceChangeText = readFileSync(join(root, 'scripts/approved-preference34-copy-change.json'), 'utf8');
assert.equal(digest(preferenceChangeText), 'f88127ad11a5b952c5d0cb90943c8bf289db0c9032e5e95c515c652568190728');
const preferenceChange = JSON.parse(preferenceChangeText);
assert.deepEqual(preferenceChange.target, { childId: '00000000-0000-4000-8000-000000000001', version: 4, field: 'data.preferences' });
assert.equal(preferenceChange.file, 'dist/preview/synthetic-ports.js');
assert.equal(preferenceChange.afterSha256, digest(fixtureBeforeQuiet35));
assert.equal(Buffer.byteLength(fixtureBeforeQuiet35), preferenceChange.afterBytes);
assert.equal(fixtureBeforeQuiet35.split(preferenceChange.after).length, 2, 'Exactly one approved source expression');
const fixtureBeforePreferenceCopy = fixtureBeforeQuiet35.replace(preferenceChange.after, preferenceChange.before);
assert.equal(digest(fixtureBeforePreferenceCopy), '815760b2f8a818de6c96037a6cf84a63bdc08f6480d097c712874c18890e50c9', 'Exact one-field inverse restores every snapshot33 byte');
assert.equal(preferenceChange.beforeSha256, digest(fixtureBeforePreferenceCopy));
assert.equal(Buffer.byteLength(fixtureBeforePreferenceCopy), preferenceChange.beforeBytes);
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].preference34BeforeSha256, digest(fixtureBeforePreferenceCopy));
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].preference34ChangesSha256, digest(preferenceChangeText));
const memoryFixtureChangesText = readFileSync(join(root, 'scripts/approved-memory33-fixture-changes.json'), 'utf8');
assert.equal(digest(memoryFixtureChangesText), '56f718752c892f907db4c7aa38fd20fd93426d519ae63c383c9c619629adc48f');
const memoryFixtureChanges = JSON.parse(memoryFixtureChangesText);
assert.equal(memoryFixtureChanges.length, 4);
let fixtureBeforeMemoryIncrement = fixtureBeforePreferenceCopy;
for (const change of memoryFixtureChanges.toReversed()) {
  assert.equal(fixtureBeforeMemoryIncrement.split(change.after).length, 2);
  fixtureBeforeMemoryIncrement = fixtureBeforeMemoryIncrement.replace(change.after, change.before);
}
assert.equal(digest(fixtureBeforeMemoryIncrement), 'd8f15097f0658c9e589078c0165ff98efc2f67856f3661a7745b8efe789be53c', 'Exact memory33 inverse restores every snapshot32 fixture byte');
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].memory33BeforeSha256, digest(fixtureBeforeMemoryIncrement));
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].memory33ChangesSha256, digest(memoryFixtureChangesText));
const preparationFixtureChangesText = readFileSync(join(root, 'scripts/approved-preparation32-fixture-changes.json'), 'utf8');
assert.equal(digest(preparationFixtureChangesText), '7a01a332d472f69a6db87faff94a699df754a4aa2427416dbe3adcc9a787d115');
const preparationFixtureChanges = JSON.parse(preparationFixtureChangesText);
assert.equal(preparationFixtureChanges.length, 6);
let fixtureBeforePreparationIncrement = fixtureBeforeMemoryIncrement;
for (const change of preparationFixtureChanges.toReversed()) {
  assert.equal(fixtureBeforePreparationIncrement.split(change.after).length, 2);
  fixtureBeforePreparationIncrement = fixtureBeforePreparationIncrement.replace(change.after, change.before);
}
assert.equal(digest(fixtureBeforePreparationIncrement), '461064eb151bff716b67a93ecc8b9305fdc2c0c05bdbf42eaa599fc2af00ef6d', 'Exact snapshot32 inverse preserves every snapshot31 fixture byte');
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].preparation32BeforeSha256, digest(fixtureBeforePreparationIncrement));
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].preparation32ChangesSha256, digest(preparationFixtureChangesText));
const summaryFixtureChangesText = readFileSync(join(root, 'scripts/approved-summary27-fixture-changes.json'), 'utf8');
assert.equal(digest(summaryFixtureChangesText), '0e0789680cb04c671160afd59977323cfd161a6c5c080e52ad3076bdc8acc0a7');
const summaryFixtureChanges = JSON.parse(summaryFixtureChangesText);
assert.equal(summaryFixtureChanges.length, 3);
let fixtureBeforeSummaryIncrement = fixtureBeforePreparationIncrement;
for (const change of summaryFixtureChanges.toReversed()) {
  assert.equal(fixtureBeforeSummaryIncrement.split(change.after).length, 2);
  fixtureBeforeSummaryIncrement = fixtureBeforeSummaryIncrement.replace(change.after, change.before);
}
assert.equal(digest(fixtureBeforeSummaryIncrement), '1299e4e16b32937a39670cf6c2af6ca40b70dae3cf794f386db1e31f30bf62e3', 'Exact summary inverse preserves every prior fixture byte');
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].summary27BeforeSha256, digest(fixtureBeforeSummaryIncrement));
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].summary27ChangesSha256, digest(summaryFixtureChangesText));
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].summary27ChildId, '00000000-0000-4000-8000-000000000001');
assert.deepEqual(product.approvedPreviewChanges['preview/synthetic-ports.js'].summary27TaskIds, ['10000000-0000-4000-8000-000000030220', '10000000-0000-4000-8000-000000030221']);
const displayTextChangesText = readFileSync(join(root, 'scripts/approved-history26-display-text.json'), 'utf8');
assert.equal(digest(displayTextChangesText), '747036d210fa93c8035cabb9960422eb2659cf6722c9b83ce9fe272ec0ea2901');
const displayTextChanges = JSON.parse(displayTextChangesText);
assert.equal(fixtureBeforeSummaryIncrement.split(displayTextChanges.addedConstant).length, 2);
let fixtureBeforeDisplayText = fixtureBeforeSummaryIncrement.replace(displayTextChanges.addedConstant, '');
for (const [before, after] of Object.entries(displayTextChanges.replacements)) {
  assert.equal(fixtureBeforeDisplayText.split(after).length, 2);
  fixtureBeforeDisplayText = fixtureBeforeDisplayText.replace(after, before);
}
assert.equal(digest(fixtureBeforeDisplayText), '44ae64574c020362d0ff14e75649061bd12fc7cfda61d211f07a959e1fce9b1a', 'Only the approved display text delta changes the independently checked44ae fixture');
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].history26DisplayTextBeforeSha256, '44ae64574c020362d0ff14e75649061bd12fc7cfda61d211f07a959e1fce9b1a');
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].history26DisplayTextAdditionsSha256, digest(displayTextChangesText));
const historyFixtureAdditionsText = readFileSync(join(root, 'scripts/approved-history26-fixture-additions.json'), 'utf8');
assert.equal(digest(historyFixtureAdditionsText), 'b5ddcb0dd68950d07b294f70eeb134206c893b11f9ef8bc11e94cb47475aeecd');
const historyFixtureAdditions = JSON.parse(historyFixtureAdditionsText);
assert.equal(fixtureBeforeSummaryIncrement.split(historyFixtureAdditions.function).length, 2);
assert.equal(fixtureBeforeSummaryIncrement.split(historyFixtureAdditions.route).length, 2);
const fixtureBeforeHistoryIncrement = fixtureBeforeSummaryIncrement.replace(historyFixtureAdditions.function, '').replace(historyFixtureAdditions.route, '');
assert.equal(digest(fixtureBeforeHistoryIncrement), '8b0f6148dab42ec98fef13182292706e07899ec6ce26321f565546d2c27f3734', 'Exact approved history delta inverse preserves all previous fixture bytes');
assert.ok(fixture.indexOf(historyFixtureAdditions.route) > fixture.indexOf("reason: 'write'"));
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].history26BeforeSha256, '8b0f6148dab42ec98fef13182292706e07899ec6ce26321f565546d2c27f3734');
assert.equal(product.approvedPreviewChanges['preview/synthetic-ports.js'].history26AdditionsSha256, digest(historyFixtureAdditionsText));
const messageFixtureAdditionsText = readFileSync(join(root, 'scripts/approved-message-fixture-additions.json'), 'utf8');
assert.equal(digest(messageFixtureAdditionsText), 'e5674086e80fb84b08fb2578f8f5028dc2cda59e482d29a70259127b012de9ca');
const messageFixtureAdditions = JSON.parse(messageFixtureAdditionsText);
const fixtureBeforeMessageIncrement = fixtureBeforeHistoryIncrement.replace(messageFixtureAdditions.function, '').replace(messageFixtureAdditions.route, '');
assert.equal(digest(fixtureBeforeMessageIncrement), '8f6d15dae34ab28f8a046c195c0a8001f5ae44252df2112c86d6e0bfbde0395c', 'Every prior fixture byte retained outside the two explicit read-only message additions');
assert.ok(fixture.indexOf(messageFixtureAdditions.route) > fixture.indexOf("reason: 'write'"), 'New message read remains after the original write guard');
const originalFixtureGuardSegments = [{"name": "transport-through-care-search", "start": "  async function transport(", "end": "    if (route === '/care/search')", "sha256": "2f894abfe50b3d0290a9d7fcf5d0185a702adb74210aef34d18cab667c2e31c4"}, {"name": "summary-endpoint-through-socket-guards", "start": "    if (route === '/summary')", "end": null, "sha256": "429912fd89c1c9e7ee90a1e3ed2e94d58cbeb6f2dfc131bd43f2c5c279b066f6"}];
for (const guard of originalFixtureGuardSegments) {
  const start = fixtureBeforeMessageIncrement.indexOf(guard.start); assert.ok(start >= 0);
  const end = guard.end === null ? fixtureBeforeMessageIncrement.length : fixtureBeforeMessageIncrement.indexOf(guard.end, start); assert.ok(end > start);
  assert.equal(digest(fixtureBeforeMessageIncrement.slice(start, end)), guard.sha256, 'Unmodified network/write/model guard: ' + guard.name);
}

function context(query = '', source = fixture) {
  const listeners = [];
  const ctx = { URL, Headers, Response, Uint8Array, DOMException, Date, Map, Set, Event, atob,
    setTimeout: fn => setTimeout(fn, 0), clearTimeout,
    location: { origin: 'https://synthetic-preview.example.invalid', href: 'https://synthetic-preview.example.invalid/' + query },
    navigator: { sendBeacon: () => { throw new Error('native beacon called'); } },
    document: { addEventListener: (...args) => listeners.push(args) },
    dispatchEvent: () => true, fetch: () => { throw new Error('native fetch called'); },
  };
  ctx.window = ctx;
  vm.runInNewContext(source, ctx);
  return { ctx, listeners };
}
const { ctx, listeners } = context();
assert.equal(listeners.length, 0, 'diagnostic controls absent by default');
assert.equal(context('?qaControls=1').listeners.length, 1, 'controls available only by explicit opt-in');
assert.equal((await (await ctx.fetch('/api/auth/get-session')).json()).user.id, 'qa-parent');
assert.equal((await (await ctx.fetch('/api/children')).json()).children.length, 2);
assert.equal((await (await ctx.fetch('/api/ai/status')).json()).available, false);
const child = '00000000-0000-4000-8000-000000000001';
assert.equal((await ctx.fetch('/api/children/' + child + '/tasks', { method: 'POST', body: '{}' })).status, 405);
assert.equal((await ctx.fetch('/api/auth/sign-in/email', { method: 'POST', body: '{}' })).status, 405);
assert.equal((await ctx.fetch('/api/unlisted')).status, 503);
await assert.rejects(ctx.fetch('https://external.example.invalid/api/children'), /external network/);
await assert.rejects(ctx.fetch('/non-api-path'), /unlisted network/);
assert.throws(() => new ctx.WebSocket('wss://external.example.invalid'), /blocks sockets/);
assert.throws(() => new ctx.EventSource('/api/events'), /blocks event streams/);
assert.equal(ctx.navigator.sendBeacon('/api/beacon'), false);
assert.equal((await ctx.fetch('/api/children/' + child + '/care/search', { method: 'POST', body: '{"query":"合成"}' })).status, 200);
const messageHeaders = { 'x-expected-user-id': 'qa-parent' };
const firstMessages = await (await ctx.fetch('/api/account/messages', { headers: messageHeaders })).json();
assert.equal(firstMessages.schemaVersion, 1); assert.equal(firstMessages.items.length, 5); assert.equal(firstMessages.complete, false);
const lastMessages = await (await ctx.fetch('/api/account/messages?' + new URLSearchParams({ cursor: firstMessages.nextCursor, scopeVersion: firstMessages.scopeVersion }), { headers: messageHeaders })).json();
assert.equal(lastMessages.items.length, 1); assert.equal(lastMessages.complete, true); assert.equal(lastMessages.asOf, firstMessages.asOf);
assert.ok(firstMessages.items.every(item => item.contents.every(content => content.body.startsWith('合成正文：'))));
assert.equal((await ctx.fetch('/api/account/messages', { method: 'POST', body: '{}' })).status, 405);
const login = context('?qaLogin=1').ctx;
assert.equal(await (await login.fetch('/api/auth/get-session')).json(), null);
const docs = context('?qaDocs=1').ctx;
assert.equal((await docs.fetch('/api/children/' + child + '/documents', { method: 'POST', body: '{}' })).status, 503);
const chat = context('?qaChat=1').ctx;
assert.equal((await (await chat.fetch('/api/children/' + child + '/messages')).json()).messages.length, 30);
assert.equal((await (await chat.fetch('/api/ai/usage')).json()).attempts, 0);

// Approved fixture increment: all data stays synthetic, child-scoped, read-only and exact-ID linked.
const qaUuid = number => `10000000-0000-4000-8000-${String(number).padStart(12, '0')}`;
const qaChildren = [child, '00000000-0000-4000-8000-000000000002'];
// Runtime projection check: current/history versions agree; only A-v4 preferences change.
const preferenceBeforeContext = context('', fixtureBeforePreferenceCopy).ctx;
for (const childId of qaChildren) {
  const prefix = '/api/children/' + childId;
  const before = (await (await preferenceBeforeContext.fetch(prefix + '/profile')).json()).profile;
  const after = (await (await ctx.fetch(prefix + '/profile')).json()).profile;
  if (childId === preferenceChange.target.childId) {
    assert.equal(after.version, 4);
    assert.equal(before.data.preferences, preferenceChange.beforeDisplayText);
    assert.equal(after.data.preferences, preferenceChange.afterDisplayText);
    assert.deepEqual({ ...after, data: { ...after.data, preferences: before.data.preferences } }, before, 'All non-preference profile fields unchanged');
  } else assert.deepEqual(after, before, 'Child B current profile unchanged');
  const priorHistory = await (await preferenceBeforeContext.fetch(prefix + '/profile/history?beforeVersion=4')).json();
  const nextHistory = await (await ctx.fetch(prefix + '/profile/history?beforeVersion=4')).json();
  assert.deepEqual(nextHistory, priorHistory, 'v3/v2/v1 and cursor stay exact');
  assert.deepEqual(nextHistory.revisions.map(row => row.version), [3, 2, 1]);
  assert.equal(nextHistory.nextBeforeVersion, null);
  const includingCurrent = await (await ctx.fetch(prefix + '/profile/history?beforeVersion=5')).json();
  assert.deepEqual(includingCurrent.revisions.find(row => row.version === 4), after, 'History current-v4 equals current profile');
}
// Real failure is distinct from successful authoritative empty; existing modes and guards stay exact.
for (const childId of qaChildren) {
  const route = '/api/children/' + childId + '/library';
  const headers = { 'x-expected-user-id': 'qa-parent' };
  for (const mode of ['normal', 'empty', 'partial', 'denied']) {
    const current = await context('?qa=' + mode).ctx.fetch(route, { headers });
    const previous = await context('?qa=' + mode, fixtureBeforeQuiet35).ctx.fetch(route, { headers });
    assert.equal(current.status, previous.status, 'Catalog unchanged mode status: ' + mode);
    assert.deepEqual(await current.json(), await previous.json(), 'Catalog unchanged mode body: ' + mode);
  }
  const normal = await (await context().ctx.fetch(route, { headers })).json();
  assert.equal(normal.items.length, 2); assert.equal(normal.complete, true); assert.equal(normal.nextCursor, null);
  const empty = await (await context('?qa=empty').ctx.fetch(route, { headers })).json();
  assert.deepEqual(empty, { items: [], nextCursor: null, complete: true }, 'Successful empty remains authoritative');
  const failure = context('?qa=error');
  assert.equal(failure.listeners.length, 0, 'No new default QA controls');
  const failed = await failure.ctx.fetch(route, { headers });
  assert.equal(failed.status, 503, 'Error mode is a real failure, never successful empty');
  assert.deepEqual(await failed.json(), { error: { code: 'synthetic_transient_read' } });
  assert.equal((await failure.ctx.fetch(route)).status, 428);
  assert.equal((await failure.ctx.fetch(route, { headers: { 'x-expected-user-id': 'other-user' } })).status, 409);
  assert.equal((await failure.ctx.fetch(route + '?cursor=not_supported', { headers })).status, 400);
  assert.equal((await context('?qa=error&qaLogin=1').ctx.fetch(route, { headers })).status, 401);
  assert.equal((await failure.ctx.fetch(route, { method: 'POST', headers })).status, 405);
}
const scopedRecordIds = [];
for (const [index, childId] of qaChildren.entries()) {
  const page = (await (await ctx.fetch('/api/children/' + childId + '/concerns')).json()).page;
  assert.equal(page.items.length, 5);
  assert.equal(page.items.filter(item => item.status === 'following').length, 2);
  assert.equal(page.items.filter(item => item.status === 'closed').length, 3);
  assert.equal(page.items.reduce((sum, item) => sum + item.events.length, 0), 24);
  const records = (await (await ctx.fetch('/api/children/' + childId + '/care/search', { method: 'POST', body: '{}' })).json()).records;
  assert.equal(records.length, 24);
  const ids = new Set(records.map(record => record.id)); assert.equal(ids.size, 24); scopedRecordIds.push(ids);
  for (const event of page.items.flatMap(item => item.events).filter(event => event.recordId)) {
    const record = records.find(item => item.id === event.recordId); assert.ok(record);
    assert.equal(record.childId, childId); assert.equal(record.text, event.title + '\n' + event.text);
    const history = (await (await ctx.fetch('/api/children/' + childId + '/care/' + event.recordId + '/history')).json()).revisions;
    assert.equal(history.length, 1); assert.equal(history[0].id, event.recordId); assert.equal(history[0].text, record.text);
  }
  const recordId = records[0].id;
  for (const [beforeVersion, count] of [[1, 0], [2, 1]]) assert.equal((await (await ctx.fetch('/api/children/' + childId + '/care/' + recordId + '/history?beforeVersion=' + beforeVersion)).json()).revisions.length, count);
  for (const [startDay, period, count] of [['2026-10-01','week',24], ['2026-10-07','day',2], ['2026-10-22','day',0]]) {
    const summary = await (await ctx.fetch('/api/children/' + childId + '/summary?startDay=' + startDay + '&period=' + period + '&timeZone=Asia%2FHong_Kong')).json();
    assert.equal(summary.records.length, count); assert.equal(summary.counts.note, count);
  }
  const decision = '/api/children/' + childId + '/agent/runs/' + qaUuid(index ? 61 : 51) + '/proposals/' + qaUuid(index ? 60 : 50) + '/decide';
  assert.equal((await ctx.fetch(decision, {method:'POST',body:'{"decision":"accept"}'})).status, 405, 'Public decision POST stays read-only; no reviewer 503 fixture');
}
assert.ok([...scopedRecordIds[0]].every(id => !scopedRecordIds[1].has(id)));
assert.equal((await ctx.fetch('/api/children/' + qaChildren[1] + '/care/' + [...scopedRecordIds[0]][0] + '/history')).status, 404);
for (const [mode, status] of [['error', 503], ['denied', 403]]) assert.equal((await context('?qa=' + mode).ctx.fetch('/api/children/' + child + '/concerns')).status, status);
assert.equal((await (await context('?qa=empty').ctx.fetch('/api/children/' + child + '/concerns')).json()).page.items.length, 0);

// Approved26 history coverage remains fixed, read-only, and derived through the existing contracts.
const originalContext = context('', fixtureBeforeHistoryIncrement).ctx;
for (const childId of qaChildren) {
  const prefix = '/api/children/' + childId;
  const read = async (path, options = {}) => { const response = await ctx.fetch(prefix + path, options); assert.equal(response.status, 200); return response.json(); };
  const profile = (await read('/profile')).profile; assert.equal(profile.version, 4);
  assert.deepEqual((await read('/profile/history?beforeVersion=4')).revisions.map(item => item.version), [3, 2, 1]);
  const tasks = (await read('/tasks')).items; assert.equal(tasks.filter(item => ['completed','cancelled'].includes(item.occurrence.state)).length, 3);
  for (const task of tasks) assert.equal((await read('/tasks/' + task.id)).task.id, task.id);
  const care = (await read('/care/search', {method:'POST',body:'{}'})).records;
  const prior = (await (await originalContext.fetch(prefix + '/care/search', {method:'POST',body:'{}'})).json()).records;
  assert.equal(prior.length, 15); for (const record of prior) assert.deepEqual(care.find(item => item.id === record.id), record);
  const versioned = care.filter(record => record.version === 2); assert.equal(versioned.length, 3);
  for (const record of versioned) assert.deepEqual((await read('/care/' + record.id + '/history?beforeVersion=2')).revisions.map(item => item.version), [1]);
  const documents = (await read('/documents?status=archived&limit=10')).page;
  assert.equal(documents.items.length, 3); assert.equal(documents.hasMore, false);
  for (const item of documents.items) { assert.equal(item.kind, 'preparation'); assert.equal(item.status, 'archived');
    assert.equal((await read('/documents/' + item.id + '/versions')).page.items.length, 2); }
  const partialDocs = context('?qa=partial').ctx;
  const first = (await (await partialDocs.fetch(prefix + '/documents?status=archived&limit=10')).json()).page;
  assert.equal(first.items.length, 0); assert.equal(first.hasMore, true); assert.equal(typeof first.nextCursor, 'string');
  const next = (await (await partialDocs.fetch(prefix + '/documents?status=archived&limit=10&cursor=' + first.nextCursor)).json()).page;
  assert.equal(next.items.length, 3); assert.equal(next.hasMore, false);
  const history = await read('/agent/history?kind=message&query=', {headers:messageHeaders});
  assert.equal(history.matches.length, 3); assert.equal(history.complete, true);
  let longReads = 0;
  for (const match of history.matches) { let offset = 0, text = '', parts = 0;
    do { const detail = await read('/agent/history/messages/' + match.id + '?offset=' + offset + '&limit=4000', {headers:messageHeaders});
      assert.equal(detail.id, match.id); assert.equal(detail.childId, childId); assert.equal(detail.offset, offset);
      text += detail.text; offset = detail.nextOffset; parts++; if (offset === null) assert.equal(text.length, detail.totalCharacters);
    } while (offset !== null); if (parts > 1) longReads++; }
  assert.equal(longReads, 1);
}

// Approved27 adds two fixed scheduled appointments only for child1; all readers use the same task records.
const summaryBeforeContext = context('', fixtureBeforeSummaryIncrement).ctx;
const summaryTaskIds = [qaUuid(30220), qaUuid(30221)];
// Snapshot32 changes only these exact terminal-task titles; all other task fields remain equal.
const approvedTaskTitleChanges = product.approvedPreviewChanges['preview/synthetic-ports.js'].preparation32TaskTitleChanges;
const expectedTaskTitleChanges = qaChildren.flatMap((childId, index) => {
  const name = index ? '合成小晴' : '合成小明', base = index ? 40200 : 30200;
  return [
    { childId, id: qaUuid(base), before: name + '：合成已完成的借書事項', after: name + '：去圖書館借書', status: 'completed' },
    { childId, id: qaUuid(base + 1), before: name + '：合成已取消的公園安排', after: name + '：公園散步', status: 'cancelled' },
    { childId, id: qaUuid(base + 2), before: name + '：合成已完成的學校交流預約（較長標題，供窄屏閱讀）', after: name + '：與老師交流近期閱讀及活動安排', status: 'completed' },
  ];
});
assert.equal(expectedTaskTitleChanges.length, 6);
assert.deepEqual(approvedTaskTitleChanges, expectedTaskTitleChanges);
assert.equal(new Set(approvedTaskTitleChanges.map(change => change.childId + ':' + change.id)).size, 6);
const verifiedTaskTitleChanges = new Set();
for (const childId of qaChildren) {
  const prefix = '/api/children/' + childId;
  const read = async (runtime, path) => { const response = await runtime.fetch(prefix + path); assert.equal(response.status, 200); return response.json(); };
  const tasks = (await read(ctx, '/tasks')).items, priorTasks = (await read(summaryBeforeContext, '/tasks')).items;
  assert.equal(tasks.length, childId === child ? 6 : 4);
  const childTitleChanges = approvedTaskTitleChanges.filter(change => change.childId === childId);
  assert.equal(childTitleChanges.length, 3);
  for (const change of childTitleChanges) assert.equal(priorTasks.filter(task => task.id === change.id).length, 1);
  const originalRowsWithTitlesReverted = tasks.filter(task => !summaryTaskIds.includes(task.id)).map(task => {
    const change = childTitleChanges.find(item => item.id === task.id);
    if (!change) return task;
    const priorTask = priorTasks.find(item => item.id === change.id);
    assert.equal(task.childId, change.childId);
    assert.equal(task.title, change.after);
    assert.equal(priorTask.title, change.before);
    assert.equal(task.occurrence.state, change.status);
    assert.equal(priorTask.occurrence.state, change.status);
    verifiedTaskTitleChanges.add(change.childId + ':' + change.id);
    return { ...task, title: change.before };
  });
  assert.deepEqual(originalRowsWithTitlesReverted, priorTasks);
  for (const period of ['startDay=2026-10-01&period=week', 'startDay=2026-10-22&period=day']) {
    const route = '/summary?' + period + '&timeZone=Asia%2FHong_Kong';
    const value = await read(ctx, route), prior = await read(summaryBeforeContext, route);
    assert.deepEqual(value.appointments.map(task => task.id), childId === child ? summaryTaskIds : []);
    let profileBeforePreferenceCopy = value.profile;
    if (childId === preferenceChange.target.childId) {
      assert.equal(value.profile.childId, preferenceChange.target.childId);
      assert.equal(prior.profile.childId, preferenceChange.target.childId);
      assert.equal(value.profile.version, preferenceChange.target.version);
      assert.equal(prior.profile.version, preferenceChange.target.version);
      assert.equal(value.profile.data.preferences, preferenceChange.afterDisplayText);
      assert.equal(prior.profile.data.preferences, preferenceChange.beforeDisplayText);
      profileBeforePreferenceCopy = { ...value.profile, data: { ...value.profile.data, preferences: preferenceChange.beforeDisplayText } };
    }
    assert.deepEqual({ ...value, appointments: [], profile: profileBeforePreferenceCopy }, prior);
    assert.deepEqual(value.appointments, tasks.filter(task => task.kind === 'appointment' && task.occurrence.state === 'scheduled'));
    assert.deepEqual(value.conflicts, tasks.filter(task => task.occurrence.state === 'needs_review'));
    for (const task of value.appointments) {
      assert.equal(task.childId, child); assert.equal(task.version, 1); assert.equal(task.occurrence.terminalBasisVersion, null);
      assert.equal(task.assigneeUserId, 'qa-parent'); assert.equal(task.createdBy, 'qa-parent');
      assert.equal(task.occurrence.dueAt, task.id === summaryTaskIds[0] ? '2026-10-24T02:00:00.000Z' : '2026-10-25T03:00:00.000Z');
      assert.deepEqual((await read(ctx, '/tasks/' + task.id)).task, task);
      const revisions = (await read(ctx, '/tasks/' + task.id + '/history')).revisions;
      assert.equal(revisions.length, 1); assert.equal(revisions[0].action, 'create'); assert.deepEqual(revisions[0].task, task);
      assert.equal((await read(ctx, '/tasks/' + task.id + '/history?beforeVersion=1')).revisions.length, 0);
    }
  }
  assert.equal((await ctx.fetch(prefix + '/tasks/' + qaUuid(999999))).status, 404);
  assert.equal((await (await context('?qa=empty').ctx.fetch(prefix + '/summary?startDay=2026-10-22&period=week&timeZone=Asia%2FHong_Kong')).json()).appointments.length, 0);
}
assert.equal(verifiedTaskTitleChanges.size, 6, 'Every exact approved child/id title change verified; other task fields deep-equal');
for (const taskId of summaryTaskIds) for (const suffix of ['', '/history']) assert.equal((await ctx.fetch('/api/children/' + qaChildren[1] + '/tasks/' + taskId + suffix)).status, 404);

class Input {
  constructor(accept = '') { this.type = 'file'; this.accept = accept; this.multiple = false; this.attrs = {}; this.clicked = false; }
  getAttribute(key) { return this.attrs[key] ?? null; }
  hasAttribute(key) { return key in this.attrs; }
  click() { this.clicked = true; }
  showPicker() { this.clicked = true; }
}
let notice = { textContent: '' };
const safetyCtx = { HTMLInputElement: Input, DOMException, document: { getElementById: () => notice, addEventListener() {} }, navigator: { mediaDevices: { getUserMedia() { throw new Error('native media called'); }, getDisplayMedia() { throw new Error('native display called'); } } } };
safetyCtx.window = safetyCtx;
vm.runInNewContext(readFileSync(join(dist, 'preview/safety.js'), 'utf8'), safetyCtx);
const photo = new Input('image/jpeg,image/png'); photo.click(); assert.equal(photo.clicked, false);
const file = new Input(); file.showPicker(); assert.equal(file.clicked, false);
const background = new Input('image/jpeg,image/png,image/webp'); background.attrs['aria-hidden'] = 'true'; background.click(); assert.equal(background.clicked, true);
const capture = new Input('image/jpeg,image/png,image/webp'); capture.attrs = { 'aria-hidden': 'true', capture: 'environment' }; capture.click(); assert.equal(capture.clicked, false);
await assert.rejects(safetyCtx.navigator.mediaDevices.getUserMedia(), error => error.name === 'NotAllowedError');
await assert.rejects(safetyCtx.navigator.mediaDevices.getDisplayMedia(), error => error.name === 'NotAllowedError');
for (const name of ['XMLHttpRequest','Worker','SharedWorker']) assert.throws(() => new safetyCtx[name](), /Synthetic preview blocks/);

console.log(JSON.stringify({ result: 'PASS', appHtml: htmlFiles.length - 1, retainedViewport: true, originalProductBundleSha256: digest(readFileSync(join(dist, bundlePath))), checked: [`all ${product.originalFileCount - product.originalHtmlCount} original non-HTML product assets unchanged`,'4 viewport files unchanged; notice38-fix1 and safety38 explicitly approved + 1 explicitly approved synthetic fixture increment','original network/write/model guard segments unchanged','5 chains/24 events/24 exact records per child; 3 terminal tasks/preparations/conversations and profile prior versions','public decision POST remains 405','child1 two scheduled appointments match exact-ID/history; six exact approved title reversions preserve every original task field',`${product.originalFileCount} original / ${files(dist).length} packaged artifact count`,'Site identity','CSP/asset ordering','static deep routes','all local asset links','synthetic auth/read contracts','blocked writes','blocked external fetch/socket/beacon','explicit chat/docs fixtures','no default diagnostic controls','attachment and media restrictions','browser-local background selection preserved'], notRun: ['browser visual/layout checks','hosted route behavior','production services'] }, null, 2));
