// Local preparation only: preserves the existing preview boundary; never builds, publishes or pushes.
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, readdirSync, lstatSync, existsSync, mkdirSync, cpSync, renameSync } from 'node:fs';
import { join, resolve, dirname, basename, isAbsolute, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const [sourceArgument, expectedBundleHash, sourceDescription] = process.argv.slice(2);
assert.ok(sourceArgument && isAbsolute(sourceArgument), 'Provide the absolute frozen export path');
assert.match(expectedBundleHash || '', /^[a-f0-9]{64}$/, 'Provide the independently confirmed frozen bundle SHA-256');
assert.ok(sourceDescription, 'Provide the honest product source/version description');
const source = resolve(sourceArgument), dist = join(root, 'dist');
assert.notEqual(source, dist);
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const readText = path => readFileSync(path, 'utf8');
const listFiles = directory => readdirSync(directory).sort().flatMap(name => {
  const path = join(directory, name), stat = lstatSync(path);
  assert.ok(!stat.isSymbolicLink(), 'Do not publish symlinks: ' + path);
  return stat.isDirectory() ? listFiles(path) : [path];
});
const sourceFiles = listFiles(source);
const bundleFiles = sourceFiles.filter(path => /^_expo\/static\/js\/web\/index-[^/]+\.js$/.test(relative(source, path)));
assert.equal(bundleFiles.length, 1, 'Expect exactly one frozen application bundle');
const bundlePath = relative(source, bundleFiles[0]);
assert.equal(sha256(readFileSync(bundleFiles[0])), expectedBundleHash, 'Frozen product bundle does not match handoff');
const priorHtml = readText(join(dist, 'index.html'));
const injection = priorHtml.match(/<head>([\s\S]*?)<title /)?.[1];
const notice = priorHtml.match(/<aside id="synthetic-preview-notice"[\s\S]*?<\/aside>/)?.[0];
assert.ok(injection?.includes("connect-src 'none'") && injection.includes('/preview/safety.js'));
assert.ok(notice?.includes('非正式版'));
assert.ok(!sourceFiles.some(path => relative(source, path).startsWith('preview/')), 'Original export must not contain an alternate preview boundary');
const staging = join(root, '.frontend-site-export-staging-' + expectedBundleHash.slice(0, 12));
const backup = join(root, '.frontend-site-before-frozen-export-' + expectedBundleHash.slice(0, 12));
assert.ok(!existsSync(staging) && !existsSync(backup), 'Prior preparation state exists; inspect before retrying');
mkdirSync(staging);
cpSync(source, staging, { recursive: true });
const kept = ['preview', 'qa', 'qa-viewport.html'];
const retainedHashes = {};
for (const item of kept) {
  const path = join(dist, item);
  for (const file of lstatSync(path).isDirectory() ? listFiles(path) : [path]) retainedHashes[relative(dist, file)] = sha256(readFileSync(file));
  cpSync(path, join(staging, item), { recursive: true });
}
// Keep previously approved preview increments explicit; never silently bless a changed fixture.
const previousProductPath = join(root, 'preview-product-manifest.json');
const previousProduct = existsSync(previousProductPath) ? JSON.parse(readText(previousProductPath)) : {};
const approvedPreviewChanges = {};
const unchangedRetainedHashes = { ...retainedHashes };
for (const [path, approval] of Object.entries(previousProduct.approvedPreviewChanges || {})) {
  assert.equal(retainedHashes[path], approval.sha256, 'Approved preview increment changed without a new explicit review: ' + path);
  approvedPreviewChanges[path] = approval;
  delete unchangedRetainedHashes[path];
}
let appHtmlCount = 0;
const productHashes = {};
for (const file of sourceFiles) {
  const rel = relative(source, file), target = join(staging, rel);
  productHashes[rel] = sha256(readFileSync(file));
  if (!rel.endsWith('.html')) continue;
  const original = readText(file);
  assert.ok(original.includes('<head>') && original.includes('<body>'), 'Unsupported export HTML entry: ' + rel);
  assert.ok(!original.includes('synthetic-preview-notice') && !original.includes('/preview/'), 'Export must be unwrapped');
  const injected = original.replace('<html  lang="en">', '<html lang="zh-Hant">').replace('<head>', '<head>' + injection).replace('<body>', '<body>' + notice);
  writeFileSync(target, injected);
  appHtmlCount++;
}
for (const [path, hash] of Object.entries(productHashes)) if (!path.endsWith('.html')) assert.equal(sha256(readFileSync(join(staging, path))), hash);
for (const [path, hash] of Object.entries(retainedHashes)) assert.equal(sha256(readFileSync(join(staging, path))), hash);
const validatorPath = join(root, 'scripts/validate-preview.mjs');
let validator = readText(validatorPath);
assert.match(validator, /const bundlePath = '[^']+';/);
const bundleHashAssertion = /assert\.equal\(digest\(readFileSync\(join\(dist, bundlePath\)\)\), '[a-f0-9]{64}'\);/;
assert.match(validator, bundleHashAssertion);
validator = validator.replace(/const bundlePath = '[^']+';/, `const bundlePath = '${bundlePath}';`)
  .replace(bundleHashAssertion, `assert.equal(digest(readFileSync(join(dist, bundlePath))), '${expectedBundleHash}');`);
// Update the exact frozen identity and counts along with the independently handed-off bundle hash.
validator = validator.replace(/assert\.equal\(product\.frozenExport, '[^']+'\);/, `assert.equal(product.frozenExport, '${basename(source)}');`)
  .replace(/assert\.equal\(product\.originalFileCount, \d+, '[^']+'\);/, `assert.equal(product.originalFileCount, ${sourceFiles.length}, 'Frozen export artifact count');`)
  .replace(/assert\.equal\(product\.originalHtmlCount, \d+, '[^']+'\);/, `assert.equal(product.originalHtmlCount, ${appHtmlCount}, 'Frozen export application HTML count');`)
  .replace(/assert\.equal\(files\(dist\)\.length, \d+, 'Frozen product plus retained preview files'\);/, `assert.equal(files(dist).length, ${sourceFiles.length + Object.keys(retainedHashes).length}, 'Frozen product plus retained preview files');`);
// Replace the frozen-file expectations together rather than retaining stale snapshot counts.
validator = validator.replace(/assert\.equal\(htmlFiles\.length, \d+, 'Frozen export HTML count plus retained viewport'\);\n/g, '');
validator = validator.replace("const htmlFiles = files(dist).filter(path => extname(path) === '.html');", `const htmlFiles = files(dist).filter(path => extname(path) === '.html');\nassert.equal(htmlFiles.length, ${appHtmlCount + 1}, 'Frozen export HTML count plus retained viewport');`);
assert.ok(validator.includes(expectedBundleHash), 'Validator hash was not updated');
renameSync(dist, backup);
renameSync(staging, dist);
writeFileSync(validatorPath, validator);
const allHashes = Object.fromEntries(listFiles(dist).map(file => [relative(dist, file), sha256(readFileSync(file))]));
writeFileSync(join(root, 'preview-build-manifest.json'), JSON.stringify(allHashes, null, 2) + '\n');
writeFileSync(join(root, 'preview-product-manifest.json'), JSON.stringify({ sourceDescription, frozenExport: basename(source), bundlePath, bundleSha256: expectedBundleHash, originalFileCount: sourceFiles.length, originalHtmlCount: appHtmlCount, originalFiles: productHashes, retainedPreviewFiles: unchangedRetainedHashes, approvedPreviewChanges }, null, 2) + '\n');
console.log(JSON.stringify({ prepared: true, sourceDescription, frozenExport: basename(source), bundlePath, bundleSha256: expectedBundleHash, originalFiles: sourceFiles.length, appHtml: appHtmlCount, packagedFiles: Object.keys(allHashes).length, retainedPreviewFilesUnchanged: Object.keys(unchangedRetainedHashes).length, approvedPreviewIncrements: Object.keys(approvedPreviewChanges).length, backup, next: 'Run validator and independent review before the Site owner packages/publishes' }, null, 2));
