# 三方案最終本機候選：第一寬版標題末核

本輪只替換第一 1facfec 的 36 HTML payload＋1 個新 hash bundle；第二 7a1e973、第三 5fa35b6、原版／預設／dispatcher／fixture／比較卡全保持。233 既有檔逐 byte 不變，27 資產碰撞皆相同。舊服務目錄不寫。

第一 source map 全 2098 sources 集合不變，只 PrepWorkspace／TasksCalendar 2 source 變，其他 2096（含 dependencies）相同；436 自有＋6 本地 dependency bytes 對 exact commit，570 frozen inputs 0 drift。heading-only AST、4/4 red-green SSR、23/23 combined SSR、tsc 原證據可追溯，不重跑其他兩份或整矩陣。

本包 270 檔已乾淨重建逐 path／bytes／SHA 一致；144 payload 還原、84 asset entries、179 VM cases、2340 local references、CSP／fixture 全通。新候選沒有 mapURL／map files；原 baseline 既有 dangling comment 仍明示保留。

精確 source／tree／SAFE manifest 見 `verification/preparation-receipt.json` 與 `../frontend-final-harbour-wide-20261026/final-three-candidates.json`；完整檔案 SHA 在 `verification/dist-manifest.json`。驗證命令 `node scripts/verify-comparison.mjs`。重建需在新目錄複製 scripts＋verification/inputs.json，再執行 `python scripts/prepare.py`；不覆寫既有 dist。

唯一 browser owner 只需補第一兩個寬版 heading。所有前批有限矩陣的限制仍適用，不宣稱真 backend／device／所有狀態測完。父主對話擁有 Sites 最終發布與 source publication gates，本 preparer 沒有 publish／push。
