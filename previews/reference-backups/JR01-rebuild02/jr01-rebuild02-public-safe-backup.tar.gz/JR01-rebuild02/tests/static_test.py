from pathlib import Path
import hashlib,json,re,unittest
R=Path(__file__).resolve().parent.parent
class ArtifactTests(unittest.TestCase):
 def test_pinned_sources_exact(self):
  rows=json.loads((R/'evidence/upstream-tree.json').read_text())['tree'];n=0
  for x in rows:
   if x['type']!='blob' or not(x['path'].startswith('frontend/') or x['path'] in ('LICENSE','README.md','config.yaml')):continue
   b=(R/'upstream'/x['path']).read_bytes();n+=1;self.assertEqual(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),x['sha'],x['path'])
  self.assertEqual(n,99)
 def test_fonts_exact_to_pinned_google_tree(self):
  meta=json.loads((R/'evidence/font-upstream.json').read_text());self.assertEqual(meta['commit'],'c30b221beb0c1da59d563feb91ec8656a1fa972a')
  for x in meta['files']:
   b=(R/'fonts'/x['path']).read_bytes();self.assertEqual(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),x['sha'])
 def test_offline_output(self):
  p=R/'public';self.assertTrue((p/'index.html').exists(),'new build missing');html=(p/'index.html').read_text()
  for term in ["connect-src 'none'","form-action 'none'","img-src data:",'id="root"']:self.assertIn(term,html)
  self.assertNotIn('fonts.googleapis.com',html)
  for u in re.findall(r'(?:href|src)="([^"]+)"',html):self.assertFalse(u.startswith(('http','//')));self.assertTrue((p/u).is_file(),u)
  self.assertFalse(list(p.rglob('Journal.png')))
 def test_actual_build_graph_excludes_original_transport(self):
  p=R/'evidence/module-graph.json';self.assertTrue(p.exists(),'new graph missing');ids=json.loads(p.read_text())['module_ids']
  for x in ['upstream/frontend/src/api.js','upstream/frontend/src/utils/mockData.js']:self.assertNotIn(x,ids)
  for x in ['upstream/frontend/src/App.jsx','upstream/frontend/src/tabs/NotesTab.jsx','upstream/frontend/src/styles.css','harness/api.mjs','harness/mock-data.mjs','harness/offline.mjs','harness/storage.mjs']:self.assertIn(x,ids)
 def test_notices_and_new_provenance(self):
  p=R/'public';self.assertTrue((p/'PROVENANCE.md').exists(),'new provenance missing');text=(p/'PROVENANCE.md').read_text();self.assertIn('JR01-rebuild02',text);self.assertIn('original archive was lost',text)
  self.assertEqual((p/'licenses/BabyTracker-MIT.txt').read_bytes(),(R/'upstream/LICENSE').read_bytes())
  for x in json.loads((p/'licenses/DEPENDENCIES.json').read_text()):
   self.assertTrue(x['files'])
   for f in x['files']:self.assertTrue((p/'licenses'/f).is_file())
if __name__=='__main__':unittest.main(verbosity=2)
