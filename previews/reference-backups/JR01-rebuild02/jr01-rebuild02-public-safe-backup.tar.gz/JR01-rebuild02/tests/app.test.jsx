import {test,expect,afterEach} from '../upstream/frontend/node_modules/vitest/dist/index.js';import {render,screen,fireEvent,cleanup} from '../upstream/frontend/node_modules/@testing-library/react/dist/index.js';
import App from '../upstream/frontend/src/App.jsx';import {PreferencesProvider} from '../upstream/frontend/src/utils/preferences.jsx';import {I18nProvider} from '../upstream/frontend/src/utils/i18n.jsx';
afterEach(cleanup);
test('new offline original-App mount preserves Journal sections and both demo children',async()=>{
 const {container}=render(<I18nProvider><PreferencesProvider><App/></PreferencesProvider></I18nProvider>);
 fireEvent.click(await screen.findByRole('button',{name:'Journal'}));await screen.findByText('Emma smiled for the first time today!');
 for(const label of ['Milestones','Medications','Notes','No milestones yet — tap + to record one','No medications recorded yet','Started showing interest in colorful toys during tummy time','Doctor visit: all vaccinations up to date, growing well'])expect(screen.getByText(label)).toBeTruthy();
 expect(container.querySelector('.tab-active').textContent).toBe('Journal');expect(container.querySelectorAll('.expand-toggle')).toHaveLength(0);
 expect(globalThis.__JR01_OFFLINE__.blockedTransports.filter(x=>x!=='EventSource')).toEqual([]);expect(globalThis.__JR01_OFFLINE__.blockedOperations).toContain('getTags');
 fireEvent.click(screen.getByRole('button',{name:'Liam'}));await screen.findByText("Liam said 'banana' clearly for the first time");
 expect(screen.getByText('Loves playing with building blocks, stacked 5 high today')).toBeTruthy();expect(screen.queryByText('Emma smiled for the first time today!')).toBeNull();
 expect(screen.getByText('No milestones yet — tap + to record one')).toBeTruthy();expect(screen.getByText('No medications recorded yet')).toBeTruthy();
});
