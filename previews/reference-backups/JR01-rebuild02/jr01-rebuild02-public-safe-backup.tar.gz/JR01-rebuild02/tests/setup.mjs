import {makeFixedDate} from '../harness/clock.mjs';import {installOfflineGuard} from '../harness/offline.mjs';import {installMemoryStorage} from '../harness/storage.mjs';
installMemoryStorage(window);installOfflineGuard(window);window.Date=makeFixedDate(window.Date);
for(const key of ['localStorage','sessionStorage','fetch','XMLHttpRequest','WebSocket','EventSource','Date','__JR01_OFFLINE__'])Object.defineProperty(globalThis,key,{configurable:true,writable:true,value:window[key]});
window.matchMedia=()=>({matches:false,addEventListener(){},removeEventListener(){}});globalThis.ResizeObserver=class{observe(){}unobserve(){}disconnect(){}};
