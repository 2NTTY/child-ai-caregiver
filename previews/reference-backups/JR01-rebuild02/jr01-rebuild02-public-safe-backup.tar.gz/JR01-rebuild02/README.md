# JR01-rebuild02: independent Journal reference backup

This package preserves a NEW BabyTracker v1.13.0 Journal rebuild after the original local JR01 archive was lost. It is not the recovered original archive. Source is pinned to mbentancour/babytracker commit bcc0513567c2fba7c935bd61886ce998a2bf1fab.

`public/` is the exact 69-file payload used by the bounded browser check. Its original preparation-stage README/provenance are intentionally unchanged; `VERIFICATION.json` records the later bounded browser result and remaining unverified areas. Use the original Overview-to-Journal navigation. The data is original synthetic demo only: Emma has three notes, Liam two, with empty milestones/medications/tags preserved.

`upstream/`, `harness/`, `fixtures/`, `fonts/` and `tests/` preserve reproducible inputs. `evidence/` contains only public-source hashes, dependency and license provenance, not private raw run logs. `verification/` contains the inspected synthetic complete desktop capture. It is not proof of mobile, accessibility, every control, or real network/backend integration.

Source MIT, font OFL and bundled dependency notices are retained in `public/licenses/`. No real household data, credentials, private raw observations, hosting metadata or internal archive is included. No existing site was published or changed. A branch backup, when separately recorded as successful, is not a PR, merge or production release.

Rebuild from this package root: install the exact `upstream/frontend/package-lock.json` with scripts disabled; run `node harness/generate.mjs`, `node harness/build.mjs`, then `python harness/package.py`. The package script also reads the root display provenance files included here. Use only the explicit harness build, not upstream's API-proxy development server.
