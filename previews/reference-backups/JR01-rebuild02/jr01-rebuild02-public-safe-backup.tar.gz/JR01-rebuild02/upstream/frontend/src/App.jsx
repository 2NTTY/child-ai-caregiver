import { useState, useEffect, useCallback, useRef, lazy, Suspense } from "react";
import { useBabyData } from "./hooks/useBabyData";
import { useTimers } from "./hooks/useTimers";
import { UnitContext } from "./utils/units";
import { Icons } from "./components/Icons";
import { colors } from "./utils/colors";
import { getAge, formatElapsed, formatTime } from "./utils/formatters";
import { api, setAccessToken, getAccessToken, setOnAuthRequired, enableTokenPersistence, bootstrapSession } from "./api";
import { usePreferences } from "./utils/preferences";
import { useI18n } from "./utils/i18n";
import { toLocalDatetime, localInputToUTC } from "./utils/datetime";
// Tabs, settings, and the picture frame are lazy so the initial bundle
// stays lean — recharts alone (Overview/Growth) would otherwise sit in the
// critical path of the login screen on slow wall-mounted tablets.
const OverviewTab = lazy(() => import("./tabs/OverviewTab"));
const GrowthTab = lazy(() => import("./tabs/GrowthTab"));
const NotesTab = lazy(() => import("./tabs/NotesTab"));
const DayTab = lazy(() => import("./tabs/DayTab"));
const RoutineTab = lazy(() => import("./tabs/RoutineTab"));
import FeedingForm from "./components/forms/FeedingForm";
import SleepForm from "./components/forms/SleepForm";
import DiaperForm from "./components/forms/DiaperForm";
import TemperatureForm from "./components/forms/TemperatureForm";
import TummyTimeForm from "./components/forms/TummyTimeForm";
import NoteForm from "./components/forms/NoteForm";
import WeightForm from "./components/forms/WeightForm";
import HeightForm from "./components/forms/HeightForm";
import HeadCircumferenceForm from "./components/forms/HeadCircumferenceForm";
import MedicationForm from "./components/forms/MedicationForm";
import MilestoneForm from "./components/forms/MilestoneForm";
import PumpingForm from "./components/forms/PumpingForm";
import MilkWasteForm from "./components/forms/MilkWasteForm";
import BMIForm from "./components/forms/BMIForm";
import TimerButton from "./components/TimerButton";
import LoginScreen from "./components/LoginScreen";
const SetupWizard = lazy(() => import("./components/SetupWizard"));
import OnboardingScreen from "./components/OnboardingScreen";
import SetupChoiceScreen from "./components/SetupChoiceScreen";
import ChildForm from "./components/forms/ChildForm";
import EditChildForm from "./components/forms/EditChildForm";
const SettingsModal = lazy(() => import("./components/SettingsModal"));
const GalleryTab = lazy(() => import("./tabs/GalleryTab"));
const PictureFrame = lazy(() => import("./components/PictureFrame"));
import "./styles.css";

// `view` marks a tab as optional: it appears only when that per-device view
// preference is on (Settings > Preferences > Views). Tabs without one are the
// original four and are always present, subject to the usual read permissions.
const TABS = [
  { id: "overview", labelKey: "nav.overview", icon: <Icons.Activity />, features: ["feeding", "sleep", "diaper", "tummy", "pumping", "temp", "medication"] },
  { id: "day", labelKey: "nav.day", icon: <Icons.Clock />, view: "day", features: ["feeding", "sleep", "diaper", "tummy", "pumping", "temp", "medication", "note"] },
  { id: "routine", labelKey: "nav.routine", icon: <Icons.Timer />, view: "routine", features: ["feeding", "sleep", "diaper", "tummy", "pumping"] },
  { id: "growth", labelKey: "nav.growth", icon: <Icons.TrendUp />, features: ["weight", "height", "headcirc", "bmi"] },
  { id: "notes", labelKey: "nav.journal", icon: <Icons.StickyNote />, features: ["note", "milestone", "medication"] },
  { id: "gallery", labelKey: "nav.photos", icon: <Icons.Baby />, features: ["photo"] },
];

const ACTION_GROUPS = [
  {
    id: "track",
    labelKey: "action.track",
    actions: [
      { id: "feeding", labelKey: "action.feeding", icon: <Icons.Bottle />, color: colors.feeding },
      { id: "sleep", labelKey: "action.sleep", icon: <Icons.Moon />, color: colors.sleep },
      { id: "diaper", labelKey: "action.diaper", icon: <Icons.Droplet />, color: colors.diaper },
      { id: "tummy", labelKey: "action.tummy", icon: <Icons.Sun />, color: colors.tummy },
      { id: "pumping", labelKey: "action.pumping", icon: <Icons.Bottle />, color: colors.pumping },
      // Rides on the pumping permission (it has no RBAC feature of its own)
      // and only appears when the milk-stock view is switched on, since
      // logging discards is pointless without a balance to subtract from.
      { id: "milkWaste", labelKey: "action.milkWaste", icon: <Icons.BottleOff />, color: colors.milkWaste, feature: "pumping", view: "milkStock" },
    ],
  },
  {
    id: "measure",
    labelKey: "action.measure",
    actions: [
      { id: "temp", labelKey: "action.temp", icon: <Icons.Temp />, color: colors.temp },
      { id: "weight", labelKey: "action.weight", icon: <Icons.Weight />, color: colors.growth },
      { id: "height", labelKey: "action.height", icon: <Icons.Ruler />, color: colors.height },
      { id: "headcirc", labelKey: "action.headCirc", icon: <Icons.Baby />, color: colors.growth },
      { id: "bmi", labelKey: "action.bmi", icon: <Icons.TrendUp />, color: colors.feeding },
    ],
  },
  {
    id: "more",
    labelKey: "action.more",
    actions: [
      { id: "note", labelKey: "action.note", icon: <Icons.StickyNote />, color: colors.note },
      { id: "medication", labelKey: "action.medication", icon: <Icons.Temp />, color: "#e67e22" },
      { id: "milestone", labelKey: "action.milestone", icon: <Icons.TrendUp />, color: "#00b894" },
    ],
  },
];

// Entry types whose permission lives under another feature. Uneaten milk is
// gated by the pumping permission server-side (see internal/models/access.go
// and pathFeatureMap in internal/middleware/rbac.go), so the client has to ask
// the same question or the edit forms silently refuse to open.
const ENTRY_FEATURE_OVERRIDES = { milkWaste: "pumping" };
const entryFeature = (type) => ENTRY_FEATURE_OVERRIDES[type] || type;

const formatPauses = (pauses) => {
  if (!pauses || pauses.length === 0) return "";
  const completedPauses = pauses.filter((p) => p.start && p.end);
  if (completedPauses.length === 0) return "";
  return completedPauses
    .map((p) => `${formatTime(p.start)}-${formatTime(p.end)}`)
    .join(", ");
};

const TIMER_TYPES = [
  { id: "feeding", labelKey: "timer.feeding", icon: <Icons.Bottle />, color: colors.feeding },
  { id: "sleep", labelKey: "timer.sleep", icon: <Icons.Moon />, color: colors.sleep },
  { id: "tummy", labelKey: "timer.tummy", icon: <Icons.Sun />, color: colors.tummy },
];


function timerNameToType(name) {
  if (!name) return "feeding";
  const n = name.toLowerCase();
  if (n.includes("sleep")) return "sleep";
  if (n.includes("tummy")) return "tummy";
  return "feeding";
}

function getTimerLabel(name, tr) {
  // Only the app's own timer kinds get a translated label; a custom name
  // created through the API is shown verbatim.
  const n = (name || "").toLowerCase();
  if (!n.includes("feed") && !n.includes("sleep") && !n.includes("tummy")) return name;
  const timer = TIMER_TYPES.find((t) => t.id === timerNameToType(name));
  return timer ? tr(timer.labelKey) : name;
}

export default function App() {
  const { t } = useI18n();
  const [authState, setAuthState] = useState("loading"); // loading, setup-choice, setup, login, authenticated
  // setupIntent carries the user's first-boot choice past the register step so
  // OnboardingScreen can skip its own "what next?" picker. null after login or
  // on a pre-existing install.
  const [setupIntent, setSetupIntent] = useState(null); // null | "fresh" | "import" | "nara"
  const [demoMode, setDemoMode] = useState(false);
  const [applianceMode, setApplianceMode] = useState(false);

  const handleLogout = useCallback(() => {
    setAccessToken(null);
    api.logout().catch(() => {});
    setAuthState("login");
  }, []);

  useEffect(() => {
    setOnAuthRequired(() => setAuthState("login"));

    // Resolve config first so demo_mode can short-circuit the auth calls.
    // Previously we ran getAuthStatus + getConfig in parallel, which meant
    // a failing getAuthStatus (e.g. DB unreachable) would reject the whole
    // Promise.all and bury the demo_mode branch under a login screen.
    api.getConfig()
      .catch(() => ({ demo_mode: false }))
      .then(async (config) => {
        setDemoMode(config.demo_mode);
        setApplianceMode(config.appliance_mode || false);
        if (config.ha_ingress) enableTokenPersistence();

        if (config.demo_mode) {
          setAuthState("authenticated");
          return;
        }
        if (config.setup_mode) {
          setAuthState("wifi-setup");
          return;
        }

        const status = await api.getAuthStatus().catch(() => ({ setup_required: false }));
        if (status.setup_required) {
          setAuthState("setup-choice");
          return;
        }
      // If we have a persisted access token, try using it directly. The api
      // request layer will refresh it if it's expired (or fall back to login).
      if (getAccessToken()) {
        setAuthState("authenticated");
        return;
      }
      // No persisted access token — re-establish from the refresh token
      // (persisted under ingress, the cookie elsewhere). Retries transient
      // failures so a flaky network on first paint doesn't strand the user at
      // a login screen when their session is actually fine.
      bootstrapSession(2).then((outcome) => {
        if (outcome === "ok") setAuthState("authenticated");
        else setAuthState("login");
      });
    });
  }, []);

  if (authState === "loading") {
    return (
      <div className="app-loading">
        <div className="loading-spinner" />
        <span style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("general.loading")}</span>
      </div>
    );
  }

  if (authState === "wifi-setup") {
    return (
      <Suspense fallback={null}>
        <SetupWizard />
      </Suspense>
    );
  }

  if (authState === "setup-choice") {
    return (
      <SetupChoiceScreen
        onCreateAccount={() => { setSetupIntent("fresh"); setAuthState("setup"); }}
        onImport={(intent) => { setSetupIntent(intent); setAuthState("setup"); }}
        onRestored={() => { setSetupIntent(null); setAuthState("login"); }}
      />
    );
  }

  if (authState === "setup" || authState === "login") {
    return (
      <LoginScreen
        isSetup={authState === "setup"}
        onAuthenticated={() => setAuthState("authenticated")}
        onBack={authState === "setup" ? () => setAuthState("setup-choice") : null}
      />
    );
  }

  return (
    <Dashboard
      demoMode={demoMode}
      applianceMode={applianceMode}
      onLogout={handleLogout}
      setupIntent={setupIntent}
      onSetupIntentConsumed={() => setSetupIntent(null)}
    />
  );
}

function Dashboard({ demoMode, applianceMode, onLogout, setupIntent, onSetupIntentConsumed }) {
  const { t: tr } = useI18n();
  const { isFeatureEnabled, isViewEnabled, getFormDefault, prefs } = usePreferences();
  const [activeTab, setActiveTab] = useState("overview");
  const [modal, setModal] = useState(null);
  const [showActions, setShowActions] = useState(false);
  const [expandedGroup, setExpandedGroup] = useState("track");
  const [showTimerPicker, setShowTimerPicker] = useState(false);
  const [editingTimerId, setEditingTimerId] = useState(null);
  const [isAdmin, setIsAdmin] = useState(demoMode);
  const [userAccess, setUserAccess] = useState([]);
  const [selectedChildId, setSelectedChildId] = useState(null);

  const [permissionsLoaded, setPermissionsLoaded] = useState(demoMode);
  useEffect(() => {
    if (demoMode) { setPermissionsLoaded(true); return; }
    api.getCurrentUserAccess()
      .then((res) => {
        setIsAdmin(res.is_admin);
        setUserAccess(res.access || []);
        setPermissionsLoaded(true);
      })
      .catch(() => setPermissionsLoaded(true));
  }, [demoMode]);

  // Permission helpers — use selectedChildId to avoid circular dep with data.child
  const getPermission = useCallback((feature) => {
    if (demoMode || isAdmin) return "write";
    if (!selectedChildId) return "none";
    const access = userAccess.find((a) => a.child_id === selectedChildId);
    if (!access) return "none";
    const perm = access.permissions?.find((p) => p.feature === feature);
    return perm?.access_level || "none";
  }, [demoMode, isAdmin, userAccess, selectedChildId]);

  const canWrite = useCallback((feature) => getPermission(feature) === "write", [getPermission]);
  const canRead = useCallback((feature) => getPermission(feature) !== "none", [getPermission]);
  const hasAnyWriteAccess = demoMode || isAdmin || userAccess.some((a) =>
    a.permissions?.some((p) => p.access_level === "write")
  );

  // Data fetching — canRead is now defined before this call
  const data = useBabyData(canRead, { milkStockEnabled: isViewEnabled("milkStock") });
  const timer = useTimers(data.timers, data.child?.id);
  // True while an onboarding import's summary is on screen: the import has
  // already created the child, and the next background refresh would
  // otherwise switch to the dashboard before the summary is read.
  const [onboardingBusy, setOnboardingBusy] = useState(false);

  // Keep selectedChildId in sync with the active child
  useEffect(() => {
    if (data.child?.id && data.child.id !== selectedChildId) {
      setSelectedChildId(data.child.id);
    }
  }, [data.child?.id, selectedChildId]);

  // Refetch data once BOTH permissions and the active child are known — the
  // first in-flight fetch inside useBabyData was gated by a canRead() that
  // returned false for everything (no selectedChildId yet for non-admins),
  // so we need a do-over. Guarded by a ref so it fires exactly once: without
  // the ref a later child switch would double-refetch.
  const didPostPermsRefetchRef = useRef(false);
  useEffect(() => {
    if (permissionsLoaded && data.child?.id && !didPostPermsRefetchRef.current) {
      didPostPermsRefetchRef.current = true;
      data.refetch();
    }
  }, [permissionsLoaded, data.child?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // A tab is visible when the user can read at least one of its features and,
  // for the optional views, when that view is switched on for this device.
  const isTabVisible = useCallback(
    (tab) => (!tab.view || isViewEnabled(tab.view)) && tab.features.some((f) => canRead(f)),
    [canRead, isViewEnabled],
  );

  // Auto-select first visible tab if current tab becomes hidden — including
  // when the user switches an optional view off while standing on it.
  useEffect(() => {
    const visibleTabs = TABS.filter(isTabVisible);
    if (visibleTabs.length > 0 && !visibleTabs.find((t) => t.id === activeTab)) {
      setActiveTab(visibleTabs[0].id);
    }
  }, [isTabVisible, activeTab]);

  // Picture frame screensaver
  const slideshowParam = new URLSearchParams(window.location.search).get("slideshow") === "true";
  const [showPictureFrame, setShowPictureFrame] = useState(false);
  const [galleryPhotos, setGalleryPhotos] = useState([]);
  const [slideshowTriggered, setSlideshowTriggered] = useState(false);

  // Picture frame: use refs so the idle timer doesn't get reset by re-renders
  const childIdRef = useRef(data.child?.id);
  childIdRef.current = data.child?.id;
  const startPictureFrameRef = useRef(null);

  // Picture frame prefs ref — so startPictureFrame always reads the latest
  const pfPrefsRef = useRef(prefs.pictureFrame);
  pfPrefsRef.current = prefs.pictureFrame;
  const childrenRef = useRef(data.children);
  childrenRef.current = data.children;

  // Fetches and filters gallery photos using current preferences. Returns the
  // list (possibly empty) without touching state. Shared by start + refresh.
  const fetchGalleryPhotos = useCallback(async () => {
    const pf = pfPrefsRef.current || {};
    const allChildren = childrenRef.current || [];

    let childIds = pf.childIds?.length > 0 ? pf.childIds : allChildren.map((c) => c.id);
    if (childIds.length === 0 && childIdRef.current) childIds = [childIdRef.current];

    const responses = await Promise.all(
      childIds.map((cid) => api.getGallery({ child: cid }).catch(() => ({ results: [] })))
    );
    let allPhotos = [];
    const seen = new Set();
    for (const res of responses) {
      for (const item of res.results || []) {
        const key = `${item.entity_type}-${item.photo}`;
        if (!seen.has(key)) {
          seen.add(key);
          allPhotos.push(item);
        }
      }
    }

    const typeFilter = {
      shared: "showShared", photo: "showPhoto", profile: "showProfile",
      milestone: "showMilestone", weight: "showWeight", height: "showHeight",
      head_circumference: "showHeadCirc", feeding: "showFeeding",
      sleep: "showSleep", tummy_time: "showTummy", diaper: "showDiaper",
      temperature: "showTemp", medication: "showMedication", note: "showNote",
    };

    return allPhotos.filter((p) => {
      const key = typeFilter[p.entity_type];
      if (key === undefined) return true;
      return pf[key] !== false;
    });
  }, []);

  const startPictureFrame = useCallback(async () => {
    try {
      const photos = await fetchGalleryPhotos();
      if (photos.length > 0) {
        setGalleryPhotos(photos);
        setShowPictureFrame(true);
      }
    } catch { /* ignore */ }
  }, [fetchGalleryPhotos]);
  startPictureFrameRef.current = startPictureFrame;

  // New photos arrive via the SSE handler below (msg.new_photo) — no polling.

  // ?slideshow=true — start picture frame as soon as child data is available
  useEffect(() => {
    if (slideshowParam && !slideshowTriggered && data.child?.id) {
      setSlideshowTriggered(true);
      startPictureFrame();
    }
  }, [slideshowParam, slideshowTriggered, data.child?.id, startPictureFrame]);

  // Idle timeout trigger — re-runs when the timeout changes OR when picture
  // frame closes (so we re-arm on a wall-mounted tablet that has no further
  // user activity to trigger the listener-based reset).
  const pictureFrameTimeout = prefs.pictureFrameTimeout;
  useEffect(() => {
    if (!pictureFrameTimeout || pictureFrameTimeout <= 0) return;
    if (showPictureFrame) return; // already showing — no idle timer needed

    let idleTimer;
    const resetTimer = () => {
      clearTimeout(idleTimer);
      idleTimer = setTimeout(() => startPictureFrame(), pictureFrameTimeout * 60 * 1000);
    };

    const events = ["mousedown", "mousemove", "keydown", "touchstart", "scroll"];
    events.forEach((e) => window.addEventListener(e, resetTimer, { passive: true }));
    resetTimer();

    return () => {
      clearTimeout(idleTimer);
      events.forEach((e) => window.removeEventListener(e, resetTimer));
    };
  }, [pictureFrameTimeout, startPictureFrame, showPictureFrame]);

  // Listen for remote display events via SSE — drives picture frame state
  // and live photo refresh. Device name is stored per browser.
  useEffect(() => {
    const deviceName = localStorage.getItem("babytracker_device_name") || "default";
    const evtSource = new EventSource(`./api/display/events?device=${encodeURIComponent(deviceName)}`);
    let isFirst = true;
    evtSource.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        if (isFirst) { isFirst = false; return; }

        // Picture frame on/off command
        if (msg.set_picture_frame) {
          if (msg.picture_frame) startPictureFrameRef.current();
          else setShowPictureFrame(false);
        }

        // New photo available — refetch the gallery so any active picture
        // frame slideshow merges it in (PictureFrame.jsx handles the merge).
        if (msg.new_photo) {
          fetchGalleryPhotos()
            .then((photos) => { if (photos.length > 0) setGalleryPhotos(photos); })
            .catch(() => {});
        }
      } catch { /* ignore */ }
    };
    return () => evtSource.close();
  }, [startPictureFrame, fetchGalleryPhotos]);

  // The avatar and name blocks in the header are the only entry point for
  // editing a child; they're divs, so keyboard access needs explicit wiring.
  const openEditChild = () => data.child && setModal({ type: "editChild", child: data.child });
  const editChildKeys = (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      openEditChild();
    }
  };

  const closeModal = () => {
    // Cancelling a timer-backed entry form leaves the timer running on the
    // server — bring its bar back right away instead of on the next poll.
    if (modal?.timerId) timer.resumeTimer(modal.timerId);
    setModal(null);
  };
  const handleFormDone = () => {
    // Deliberately not closeModal(): saving deletes the server timer, so the
    // suppressed bar must stay hidden (the next refetch cleans it up).
    setModal(null);
    data.refetch();
  };

  const handleDeleteEntry = async (type, id) => {
    try {
      const deleteFns = {
        feeding: api.deleteFeeding,
        sleep: api.deleteSleep,
        diaper: api.deleteChange,
        tummy: api.deleteTummyTime,
        temp: api.deleteTemperature,
        weight: api.deleteWeight,
        height: api.deleteHeight,
        headcirc: api.deleteHeadCircumference,
        medication: api.deleteMedication,
        milestone: api.deleteMilestone,
        note: api.deleteNote,
        pumping: api.deletePumping,
        milkWaste: api.deleteMilkWaste,
        bmi: api.deleteBMI,
        child: api.deleteChild,
      };
      const fn = deleteFns[type];
      if (fn) {
        await fn(id);
        data.refetch();
      }
    } catch (err) {
      console.error("Delete failed:", err);
    }
  };

  if (data.loading) {
    return (
      <div className="app-loading">
        <div className="loading-spinner" />
        <span style={{ color: "var(--text-muted)", fontSize: 14 }}>{tr("general.loading")}</span>
      </div>
    );
  }

  if (!demoMode && (data.children.length === 0 || onboardingBusy)) {
    if (isAdmin) {
      return (
        <OnboardingScreen
          onChildAdded={data.refetch}
          initialMode={setupIntent}
          onInitialModeConsumed={onSetupIntentConsumed}
          unitSystem={data.unitSystem}
          onUnitSystemChange={data.setUnitSystem}
          onBusy={setOnboardingBusy}
        />
      );
    }
    return (
      <div className="app-loading">
        <span style={{ color: "var(--text-muted)", fontSize: 14, textAlign: "center", padding: 20 }}>
          {tr("onboarding.noAccess")}<br />
          {tr("onboarding.askAdmin")}
        </span>
      </div>
    );
  }

  return (
    <UnitContext.Provider value={data.unitSystem}>
    <div className="app">
      {/* Header */}
      <header className="app-header fade-in">
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div
            className="avatar"
            style={{ cursor: "pointer" }}
            role="button"
            tabIndex={0}
            aria-label={tr("general.tapToEdit")}
            onClick={openEditChild}
            onKeyDown={editChildKeys}
            title={tr("general.tapToEdit")}
          >
            {data.child?.picture ? (
              <img src={data.child.picture} alt={data.child.first_name} className="avatar-img" />
            ) : (
              <Icons.Baby />
            )}
          </div>
          <div
            style={{ cursor: "pointer" }}
            role="button"
            tabIndex={0}
            aria-label={tr("general.tapToEdit")}
            onClick={openEditChild}
            onKeyDown={editChildKeys}
            title={tr("general.tapToEdit")}
          >
            <h1 className="baby-name">
              {data.child?.first_name || tr("general.baby")}
            </h1>
            {data.child?.birth_date && (
              <span className="baby-age">{getAge(data.child.birth_date, tr)}</span>
            )}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {data.error && (
            <span className="sync-error">{tr("general.connectionError")}</span>
          )}
          <button className="refresh-btn" onClick={() => setModal({ type: "settings" })} title={tr("settings.title")} aria-label={tr("settings.title")}>
            <Icons.Settings />
          </button>
        </div>
      </header>

      {/* Child Switcher — only shown when more than one child. The "add baby"
          action lives in the header for admins so a single-child setup doesn't
          carry an empty row. */}
      {data.children.length > 1 && (
        <div className="child-switcher fade-in">
          {data.children.map((c) => (
            <button
              key={c.id}
              className={`child-chip${c.id === data.child?.id ? " child-chip-active" : ""}`}
              onClick={() => data.selectChild(c.id)}
            >
              {c.first_name}
            </button>
          ))}
        </div>
      )}

      {/* Active Timer Bars */}
      {timer.activeTimers.map((t) => (
        <div key={t.id} className="timer-bar fade-in">
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span className="timer-pulse" />
            <Icons.Timer />
            <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
              <span style={{ fontSize: 13, fontWeight: 500 }}>
                {getTimerLabel(t.name, tr)}
                {data.children.length > 1 && (
                  <span style={{ fontSize: 11, color: "var(--text-dim)", marginLeft: 6 }}>
                    ({data.children.find((c) => c.id === t.childId)?.first_name})
                  </span>
                )}
              </span>
              {formatPauses(t.pauses) && (
                <span style={{ fontSize: 10, color: "var(--text-dim)" }}>
                  {tr("timer.pauses")}: {formatPauses(t.pauses)}
                </span>
              )}
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {editingTimerId === t.id ? (
              <input
                type="datetime-local"
                className="timer-edit-input"
                defaultValue={toLocalDatetime(t.start)}
                autoFocus
                onBlur={(e) => {
                  if (e.target.value) {
                    timer.editTimer(t.id, localInputToUTC(e.target.value));
                  }
                  setEditingTimerId(null);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") e.target.blur();
                  if (e.key === "Escape") setEditingTimerId(null);
                }}
              />
            ) : (
              <span
                className="timer-elapsed"
                style={{ cursor: "pointer" }}
                title={tr("timer.editStart")}
                onClick={() => setEditingTimerId(t.id)}
              >
                {formatElapsed(timer.elapsedMap[t.id] || 0)}
              </span>
            )}
            <button
              className="timer-pause-btn"
              onClick={() => timer.pauseTimer(t.id)}
              title={tr("timer.pause")}
              aria-label={tr("timer.pause")}
            >
              <Icons.Pause />
            </button>
            <button
              className="timer-save-btn"
              onClick={async () => {
                const stopped = await timer.stopTimer(t.id);
                if (stopped) {
                  setModal({ type: timerNameToType(stopped.name), timerId: stopped.id });
                }
              }}
              title={tr("timer.save")}
              aria-label={tr("timer.save")}
            >
              <Icons.Save />
            </button>
            <button
              className="timer-discard-btn"
              onClick={() => timer.discardTimer(t.id)}
              title={tr("timer.discard")}
              aria-label={tr("timer.discard")}
            >
              <Icons.X />
            </button>
          </div>
        </div>
      ))}

      {/* Paused Timer Bars */}
      {timer.pausedTimers.map((t) => (
        <div key={t.id} className="timer-bar timer-bar-paused fade-in">
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span className="timer-pulse" style={{ opacity: 0.5 }} />
            <Icons.Timer style={{ opacity: 0.7 }} />
            <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
              <span style={{ fontSize: 13, fontWeight: 500, opacity: 0.8 }}>
                {getTimerLabel(t.name, tr)}
                {data.children.length > 1 && (
                  <span style={{ fontSize: 11, color: "var(--text-dim)", marginLeft: 6 }}>
                    ({data.children.find((c) => c.id === t.childId)?.first_name})
                  </span>
                )}
              </span>
              {formatPauses(t.pauses) && (
                <span style={{ fontSize: 10, color: "var(--text-dim)", opacity: 0.7 }}>
                  {tr("timer.pauses")}: {formatPauses(t.pauses)}
                </span>
              )}
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {editingTimerId === t.id ? (
              <input
                type="datetime-local"
                className="timer-edit-input"
                defaultValue={toLocalDatetime(t.start)}
                autoFocus
                onBlur={(e) => {
                  if (e.target.value) {
                    timer.editTimer(t.id, localInputToUTC(e.target.value));
                  }
                  setEditingTimerId(null);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") e.target.blur();
                  if (e.key === "Escape") setEditingTimerId(null);
                }}
              />
            ) : (
              <span
                className="timer-elapsed"
                style={{ cursor: "pointer" }}
                title={tr("timer.editStart")}
                onClick={() => setEditingTimerId(t.id)}
              >
                {formatElapsed(timer.elapsedMap[t.id] || 0)}
              </span>
            )}
            <button
              className="timer-resume-btn"
              onClick={() => timer.resumePausedTimer(t.id)}
              title={tr("timer.resume")}
              aria-label={tr("timer.resume")}
            >
              <Icons.Play />
            </button>
            <button
              className="timer-save-btn"
              onClick={async () => {
                const stopped = await timer.stopTimer(t.id);
                if (stopped) {
                  setModal({ type: timerNameToType(stopped.name), timerId: stopped.id });
                }
              }}
              title={tr("timer.save")}
              aria-label={tr("timer.save")}
            >
              <Icons.Save />
            </button>
            <button
              className="timer-discard-btn"
              onClick={() => timer.discardTimer(t.id)}
              title={tr("timer.discard")}
              aria-label={tr("timer.discard")}
            >
              <Icons.X />
            </button>
          </div>
        </div>
      ))}

      {/* Tab Navigation — bar on desktop, dropdown on mobile */}
      {(() => {
        const visibleTabs = TABS.filter(isTabVisible);
        return (
          <>
            <nav className="tab-nav tab-nav-desktop fade-in">
              {visibleTabs.map((tab) => (
                <button
                  key={tab.id}
                  className={`tab-btn ${activeTab === tab.id ? "tab-active" : ""}`}
                  onClick={() => setActiveTab(tab.id)}
                >
                  {tab.icon}
                  {tr(tab.labelKey)}
                </button>
              ))}
            </nav>
            <div className="tab-nav-mobile fade-in">
              <select
                className="tab-select"
                value={activeTab}
                onChange={(e) => setActiveTab(e.target.value)}
              >
                {visibleTabs.map((tab) => (
                  <option key={tab.id} value={tab.id}>{tr(tab.labelKey)}</option>
                ))}
              </select>
            </div>
          </>
        );
      })()}

      {/* Tab Content */}
      <main className="tab-content">
        <Suspense
          fallback={
            <div style={{ display: "flex", justifyContent: "center", padding: 40 }}>
              <span style={{ color: "var(--text-muted)", fontSize: 14 }}>{tr("general.loading")}</span>
            </div>
          }
        >
        {activeTab === "overview" && (
          <OverviewTab
            feedings={data.feedings}
            weeklyFeedings={data.weeklyFeedings}
            sleepEntries={data.sleepEntries}
            weeklySleep={data.weeklySleep}
            changes={data.changes}
            weeklyChanges={data.weeklyChanges}
            tummyTimes={data.tummyTimes}
            weeklyTummyTimes={data.weeklyTummyTimes}
            pumpingSessions={data.pumpingSessions}
            weeklyPumping={data.weeklyPumping}
            weeklyMilkWaste={data.weeklyMilkWaste}
            milkStock={data.milkStock}
            temperatures={data.temperatures}
            medications={data.medications}
            tagMaps={data.tagMaps}
            onEditEntry={(type, entry) => canWrite(entryFeature(type)) && setModal({ type, entry })}
            onDeleteEntry={(type, id) => canWrite(entryFeature(type)) && handleDeleteEntry(type, id)}
            canWrite={canWrite}
          />
        )}
        {activeTab === "day" && (
          <DayTab
            childId={data.child?.id}
            canRead={canRead}
            canWrite={canWrite}
            onEditEntry={(type, entry) => canWrite(entryFeature(type)) && setModal({ type, entry })}
          />
        )}
        {activeTab === "routine" && (
          <RoutineTab childId={data.child?.id} canRead={canRead} />
        )}
        {activeTab === "growth" && (
          <GrowthTab
            weights={data.weights}
            heights={data.heights}
            headCircumferences={data.headCircumferences}
            bmiEntries={data.bmiEntries}
            monthlyFeedings={data.monthlyFeedings}
            monthlySleep={data.monthlySleep}
            monthlyPumping={data.monthlyPumping}
            child={data.child}
            tagMaps={data.tagMaps}
            onEditEntry={(type, entry) => canWrite(entryFeature(type)) && setModal({ type, entry })}
            onDeleteEntry={(type, id) => canWrite(entryFeature(type)) && handleDeleteEntry(type, id)}
            canWrite={canWrite}
          />
        )}
        {activeTab === "notes" && (
          <NotesTab
            notes={data.notes}
            milestones={data.milestones}
            medications={data.medications}
            tagMaps={data.tagMaps}
            onEditEntry={(type, entry) => canWrite(entryFeature(type)) && setModal({ type, entry })}
            onDeleteEntry={(type, id) => canWrite(entryFeature(type)) && handleDeleteEntry(type, id)}
            canWrite={canWrite}
          />
        )}
        {activeTab === "gallery" && (
          <GalleryTab childId={data.child?.id} children={data.children} canWrite={canWrite("photo")} />
        )}
        </Suspense>
      </main>

      {/* Quick Action FAB */}
      <div className="fab-container">
        {showActions && (
          <div className="fab-menu fade-in">
            {ACTION_GROUPS.map((group) => {
              const filteredActions = group.actions.filter((a) => {
                // An action may borrow another feature's permission (`feature`)
                // and may additionally be gated on an optional view (`view`).
                if (a.view && !isViewEnabled(a.view)) return false;
                const feature = a.feature || a.id;
                return isFeatureEnabled(feature) && canWrite(feature);
              });
              if (filteredActions.length === 0) return null;
              const isOpen = expandedGroup === group.id;
              return (
                <div key={group.id} className="fab-group">
                  <button
                    className={`fab-group-label${isOpen ? " fab-group-label-active" : ""}`}
                    onClick={() => setExpandedGroup(isOpen ? null : group.id)}
                  >
                    {tr(group.labelKey)}
                  </button>
                  {isOpen && (
                    <div className="fab-group-items">
                      {filteredActions.map((action) => (
                        <button
                          key={action.id}
                          className="fab-action"
                          onClick={() => {
                            setModal({ type: action.id });
                            setShowActions(false);
                          }}
                        >
                          <span
                            className="fab-action-icon"
                            style={{ background: `${action.color}18`, color: action.color }}
                          >
                            {action.icon}
                          </span>
                          <span className="fab-action-label">{tr(action.labelKey)}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
        {showTimerPicker && (
          <div className="fab-menu fade-in" style={{ right: 76 }}>
            {TIMER_TYPES.filter((t) => canWrite(t.id === "tummy" ? "tummy" : t.id === "sleep" ? "sleep" : "feeding")).map((t) => (
              <button
                key={t.id}
                className="fab-action"
                onClick={() => {
                  timer.startTimer(t.id);
                  setShowTimerPicker(false);
                }}
              >
                <span
                  className="fab-action-icon"
                  style={{ background: `${t.color}18`, color: t.color }}
                >
                  {t.icon}
                </span>
                <span className="fab-action-label">{tr(t.labelKey)}</span>
              </button>
            ))}
          </div>
        )}
        {(canWrite("feeding") || canWrite("sleep") || canWrite("tummy")) && (
          <TimerButton
            label={tr("timer.label")}
            icon={<Icons.Timer />}
            color={colors.feeding}
            active={false}
            onClick={() => {
              setShowTimerPicker(!showTimerPicker);
              setShowActions(false);
            }}
          />
        )}
        {hasAnyWriteAccess && (
          <button
            className="fab-btn"
            style={{ background: showActions ? "var(--text-muted)" : colors.feeding }}
            onClick={() => { setShowActions(!showActions); setShowTimerPicker(false); setExpandedGroup("track"); }}
          >
            <span style={{ transform: showActions ? "rotate(45deg)" : "none", transition: "transform 0.2s", display: "flex" }}>
              <Icons.Plus />
            </span>
          </button>
        )}
      </div>

      {/* Modals */}
      {modal?.type === "feeding" && (
        <FeedingForm
          childId={data.child?.id}
          timerId={modal.timerId}
          entry={modal.entry}
          defaultType={getFormDefault("feeding", "type")}
          defaultMethod={getFormDefault("feeding", "method")}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("feeding", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "sleep" && (
        <SleepForm
          childId={data.child?.id}
          timerId={modal.timerId}
          entry={modal.entry}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("sleep", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "diaper" && (
        <DiaperForm
          childId={data.child?.id}
          entry={modal.entry}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("diaper", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "temp" && (
        <TemperatureForm
          childId={data.child?.id}
          entry={modal.entry}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("temp", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "tummy" && (
        <TummyTimeForm
          childId={data.child?.id}
          timerId={modal.timerId}
          entry={modal.entry}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("tummy", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "weight" && (
        <WeightForm
          childId={data.child?.id}
          entry={modal.entry}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("weight", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "height" && (
        <HeightForm
          childId={data.child?.id}
          entry={modal.entry}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("height", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "note" && (
        <NoteForm
          childId={data.child?.id}
          entry={modal.entry}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("note", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "headcirc" && (
        <HeadCircumferenceForm
          childId={data.child?.id}
          entry={modal.entry}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("headcirc", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "medication" && (
        <MedicationForm
          childId={data.child?.id}
          entry={modal.entry}
          defaultDosageUnit={getFormDefault("medication", "dosage_unit")}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("medication", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "bmi" && (
        <BMIForm
          childId={data.child?.id}
          entry={modal.entry}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("bmi", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "pumping" && (
        <PumpingForm
          childId={data.child?.id}
          entry={modal.entry}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("pumping", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "milkWaste" && (
        <MilkWasteForm
          childId={data.child?.id}
          entry={modal.entry}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("milkWaste", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "milestone" && (
        <MilestoneForm
          childId={data.child?.id}
          entry={modal.entry}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={modal.entry ? () => { handleDeleteEntry("milestone", modal.entry.id); closeModal(); } : undefined}
        />
      )}
      {modal?.type === "addChild" && (
        <ChildForm
          onDone={handleFormDone}
          onClose={closeModal}
        />
      )}
      {modal?.type === "editChild" && modal.child && (
        <EditChildForm
          child={modal.child}
          onDone={handleFormDone}
          onClose={closeModal}
          onDelete={isAdmin ? () => { handleDeleteEntry("child", modal.child.id); closeModal(); } : undefined}
          onAddBaby={isAdmin ? () => setModal({ type: "addChild" }) : undefined}
        />
      )}
      {modal?.type === "settings" && (
        <Suspense fallback={null}>
        <SettingsModal
          childId={data.child?.id}
          unitSystem={data.unitSystem}
          onUnitSystemChange={data.setUnitSystem}
          children={data.children}
          isAdmin={isAdmin}
          applianceMode={applianceMode}
          onClose={closeModal}
          onLogout={demoMode ? undefined : onLogout}
          onRefetch={data.refetch}
        />
        </Suspense>
      )}
      {showPictureFrame && galleryPhotos.length > 0 && (
        <Suspense fallback={null}>
        <PictureFrame
          photos={galleryPhotos}
          children={data.children}
          onWake={() => {
            setShowPictureFrame(false);
            // Remove ?slideshow=true from URL so it doesn't restart
            if (slideshowParam) {
              const url = new URL(window.location);
              url.searchParams.delete("slideshow");
              window.history.replaceState({}, "", url);
            }
          }}
        />
        </Suspense>
      )}
    </div>
    </UnitContext.Provider>
  );
}
