import { useState } from "react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import SectionCard from "../components/SectionCard";
import StatCard from "../components/StatCard";
import CustomTooltip from "../components/CustomTooltip";
import ChartDetailBar from "../components/ChartDetailBar";
import DayActivitiesModal from "../components/DayActivitiesModal";
import WHOGrowthChart from "../components/WHOGrowthChart";
import AddButton from "../components/AddButton";
import { Icons } from "../components/Icons";
import { colors } from "../utils/colors";
import { useUnits } from "../utils/units";
import { toGrowthSeries, formatGrowthTick, dailyAmountTotals, dailyCounts, dailyFeedingCountsByType, dailySleepTotals, getEntriesForDate, avgFeedingGap, avgBreastDuration, formatHoursMinutes, FEEDING_COUNT_KEYS } from "../utils/formatters";
import { usePreferences, FEEDING_TYPES } from "../utils/preferences";
import { useI18n } from "../utils/i18n";

// Labels come from the canonical FEEDING_TYPES i18n keys; a type without an
// explicit color falls back to the "other" gray.
const feedingCountLabelKeys = {
  ...Object.fromEntries(FEEDING_TYPES.map((ft) => [ft.value, ft.labelKey])),
  other: "feeding.other",
};
const feedingCountFills = {
  "breast milk": colors.feeding,
  formula: "#F9A826",
  "fortified breast milk": "#FFB74D",
  "solid food": "#81C784",
  other: "#B0BEC5",
};

export default function GrowthTab({ weights, heights, headCircumferences = [], bmiEntries = [], monthlyFeedings, monthlySleep, monthlyPumping = [], child, onEditEntry, onDeleteEntry, canWrite = () => true }) {
  const units = useUnits();
  const { t } = useI18n();
  const { prefs, isFeatureEnabled } = usePreferences();
  const [dayModal, setDayModal] = useState(null);
  const [selectedBar, setSelectedBar] = useState(null);
  const [whoView, setWhoView] = useState({ weight: false, height: false, headcirc: false, bmi: false });
  const birthDate = child?.birth_date;
  const sex = child?.sex;
  const canShowWHO = !!(birthDate && sex);
  const weightSeries = toGrowthSeries(weights, "weight");
  const heightSeries = toGrowthSeries(heights, "height");
  const headCircSeries = toGrowthSeries(headCircumferences, "head_circumference");
  const feedingSeries = dailyAmountTotals(monthlyFeedings);
  const feedingCountSeries = dailyFeedingCountsByType(monthlyFeedings);
  const sleepSeries = dailySleepTotals(monthlySleep);
  const sleepCountSeries = dailyCounts(monthlySleep);
  const pumpingSeries = dailyAmountTotals(monthlyPumping);
  const pumpingCountSeries = dailyCounts(monthlyPumping);

  const latestWeight = weights[0];
  const latestHeight = heights[0];
  const latestHeadCirc = headCircumferences[0];

  // BMI: prefer manual entry, fall back to calculated if auto-calculate is enabled
  const latestManualBMI = bmiEntries[0];
  const calculatedBMI = latestWeight && latestHeight && latestHeight.height > 0
    ? (latestWeight.weight / ((latestHeight.height / 100) ** 2)).toFixed(1)
    : null;

  const bmi = latestManualBMI
    ? { value: latestManualBMI.bmi.toFixed(1), source: "manual", date: latestManualBMI.date }
    : prefs.autoCalculateBMI && calculatedBMI
      ? { value: calculatedBMI, source: "calculated", date: null }
      : null;

  // Build BMI series for chart: combine manual entries with calculated fill-ins
  const bmiSeries = (() => {
    const manual = toGrowthSeries(bmiEntries, "bmi");
    if (!prefs.autoCalculateBMI) return manual;

    // Build a set of dates that have manual entries
    const manualDates = new Set(manual.map((m) => m.dateStr));

    // Calculate BMI for each weight entry that doesn't have a manual BMI
    const calculated = [];
    for (const w of weights) {
      const wDate = (w.date || "").slice(0, 10);
      if (manualDates.has(wDate)) continue;
      // Find closest height
      const h = heights.find((h) => h.date <= w.date) || heights[0];
      if (h && h.height > 0) {
        const bmiVal = w.weight / ((h.height / 100) ** 2);
        calculated.push({
          timestamp: new Date(wDate).getTime(),
          bmi: parseFloat(bmiVal.toFixed(1)),
          dateStr: wDate,
          entry: null,
        });
      }
    }

    return [...manual, ...calculated].sort((a, b) => a.timestamp - b.timestamp);
  })();

  // Compute averages for stat cards
  const feedingDays = feedingSeries.filter((d) => d.amount > 0);
  const avgFeeding = feedingDays.length
    ? Math.round(feedingDays.reduce((s, d) => s + d.amount, 0) / feedingDays.length)
    : 0;
  const sleepDays = sleepSeries.filter((d) => d.hours > 0);
  const avgSleep = sleepDays.length
    ? (sleepDays.reduce((s, d) => s + d.hours, 0) / sleepDays.length).toFixed(1)
    : 0;
  // Both derived from the raw 30-day entries rather than the daily buckets:
  // spacing and session length are properties of individual feeds, and the
  // per-day totals have already thrown that away.
  const feedingGap = avgFeedingGap(monthlyFeedings);
  const breastDuration = avgBreastDuration(monthlyFeedings);

  // Recharts v3 removed `activePayload` from the chart click event — we have
  // `activeLabel`, `activeTooltipIndex`/`activeIndex`, `activeDataKey` and
  // `activeCoordinate`, but not the payload. Resolve the clicked point by
  // indexing into the series array ourselves; the clicked row carries an
  // `entry` pointer we need to open the edit form.
  const handleChartClick = (data, type, seriesData, dataKey) => {
    if (!data || !seriesData) return;
    const idx = data.activeTooltipIndex ?? data.activeIndex;
    if (idx == null || idx < 0 || idx >= seriesData.length) return;
    const point = seriesData[idx];
    if (!point) return;
    setSelectedBar({
      type,
      label: data.activeLabel ?? point.timestamp ?? point.date,
      value: point[dataKey],
      entry: point.entry,
    });
  };

  const openDayModal = (dateLabel, type) => {
    let dayData = [];
    if (type === "feeding") {
      dayData = getEntriesForDate(monthlyFeedings, dateLabel, "start");
    } else if (type === "sleep") {
      dayData = getEntriesForDate(monthlySleep, dateLabel, "start");
    } else if (type === "pumping") {
      dayData = getEntriesForDate(monthlyPumping, dateLabel, "start");
    }
    setSelectedBar(null);
    setDayModal({ day: dateLabel, type, data: dayData });
  };

  return (
    <>
      {/* Latest Measurements */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))",
          gap: 14,
          marginBottom: 20,
        }}
      >
        {isFeatureEnabled("weight") && <div className="fade-in fade-in-1">
          <div
            onClick={() => latestWeight && canWrite("weight") && onEditEntry?.("weight", latestWeight)}
            style={{
              background: "var(--card-bg)",
              borderRadius: 16,
              padding: "20px 22px",
              border: "1px solid var(--border)",
              position: "relative",
              cursor: latestWeight && canWrite("weight") ? "pointer" : "default",
            }}
          >
            {canWrite("weight") && (
              <div style={{ position: "absolute", top: 10, right: 10 }} onClick={(e) => e.stopPropagation()}>
                <AddButton onClick={() => onEditEntry?.("weight")} color={colors.growth} label={t("growth.weight")} />
              </div>
            )}
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <div
                style={{
                  width: 30,
                  height: 30,
                  borderRadius: 8,
                  background: `${colors.growth}18`,
                  color: colors.growth,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Icons.Weight />
              </div>
              <span style={{ fontSize: 12, color: "var(--text-dim)", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.03em" }}>
                {t("growth.weight")}
              </span>
            </div>
            <div style={{ fontSize: 28, fontWeight: 700, color: "var(--text)", letterSpacing: "-0.02em" }}>
              {latestWeight ? `${latestWeight.weight} ${units.weight}` : "—"}
            </div>
            {latestWeight && (
              <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 4 }}>
                {new Date(latestWeight.date).toLocaleDateString()}
              </div>
            )}
          </div>
        </div>}

        {isFeatureEnabled("height") && <div className="fade-in fade-in-2">
          <div
            onClick={() => latestHeight && canWrite("height") && onEditEntry?.("height", latestHeight)}
            style={{
              background: "var(--card-bg)",
              borderRadius: 16,
              padding: "20px 22px",
              border: "1px solid var(--border)",
              position: "relative",
              cursor: latestHeight && canWrite("height") ? "pointer" : "default",
            }}
          >
            {canWrite("height") && (
              <div style={{ position: "absolute", top: 10, right: 10 }} onClick={(e) => e.stopPropagation()}>
                <AddButton onClick={() => onEditEntry?.("height")} color={colors.height} label={t("growth.height")} />
              </div>
            )}
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <div
                style={{
                  width: 30,
                  height: 30,
                  borderRadius: 8,
                  background: `${colors.height}18`,
                  color: colors.height,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Icons.Ruler />
              </div>
              <span style={{ fontSize: 12, color: "var(--text-dim)", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.03em" }}>
                {t("growth.height")}
              </span>
            </div>
            <div style={{ fontSize: 28, fontWeight: 700, color: "var(--text)", letterSpacing: "-0.02em" }}>
              {latestHeight ? `${latestHeight.height} ${units.length}` : "—"}
            </div>
            {latestHeight && (
              <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 4 }}>
                {new Date(latestHeight.date).toLocaleDateString()}
              </div>
            )}
          </div>
        </div>}

        {isFeatureEnabled("headcirc") && <div className="fade-in fade-in-3">
          <div
            onClick={() => latestHeadCirc && canWrite("headcirc") && onEditEntry?.("headcirc", latestHeadCirc)}
            style={{
              background: "var(--card-bg)",
              borderRadius: 16,
              padding: "20px 22px",
              border: "1px solid var(--border)",
              position: "relative",
              cursor: latestHeadCirc && canWrite("headcirc") ? "pointer" : "default",
            }}
          >
            {canWrite("headcirc") && (
              <div style={{ position: "absolute", top: 10, right: 10 }} onClick={(e) => e.stopPropagation()}>
                <AddButton onClick={() => onEditEntry?.("headcirc")} color={colors.growth} label={t("growth.headCirc")} />
              </div>
            )}
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <div style={{ width: 30, height: 30, borderRadius: 8, background: `${colors.growth}18`, color: colors.growth, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Icons.Baby />
              </div>
              <span style={{ fontSize: 12, color: "var(--text-dim)", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.03em" }}>{t("growth.headCirc")}</span>
            </div>
            <div style={{ fontSize: 28, fontWeight: 700, color: "var(--text)", letterSpacing: "-0.02em" }}>
              {latestHeadCirc ? `${latestHeadCirc.head_circumference} ${units.length}` : "—"}
            </div>
            {latestHeadCirc && (
              <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 4 }}>
                {new Date(latestHeadCirc.date).toLocaleDateString()}
              </div>
            )}
          </div>
        </div>}

        {isFeatureEnabled("bmi") && <div className="fade-in fade-in-4">
          <div
            onClick={() => latestManualBMI && canWrite("bmi") && onEditEntry?.("bmi", latestManualBMI)}
            style={{
              background: "var(--card-bg)",
              borderRadius: 16,
              padding: "20px 22px",
              border: "1px solid var(--border)",
              position: "relative",
              // Only manual BMI entries are editable — the other source is a
              // weight/height-derived calculation with no row to edit.
              cursor: latestManualBMI && canWrite("bmi") ? "pointer" : "default",
            }}
          >
            {canWrite("bmi") && (
              <div style={{ position: "absolute", top: 10, right: 10 }} onClick={(e) => e.stopPropagation()}>
                <AddButton onClick={() => onEditEntry?.("bmi")} color={colors.feeding} label={t("growth.bmi")} />
              </div>
            )}
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <div style={{ width: 30, height: 30, borderRadius: 8, background: `${colors.feeding}18`, color: colors.feeding, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Icons.TrendUp />
              </div>
              <span style={{ fontSize: 12, color: "var(--text-dim)", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.03em" }}>{t("growth.bmi")}</span>
            </div>
            <div style={{ fontSize: 28, fontWeight: 700, color: "var(--text)", letterSpacing: "-0.02em" }}>
              {bmi ? bmi.value : "—"}
            </div>
            <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 4 }}>
              {bmi
                ? bmi.source === "manual"
                  ? `${t("growth.doctorValue")} · ${new Date(bmi.date).toLocaleDateString()}`
                  : t("growth.calculatedFrom", { weight: `${latestWeight.weight} ${units.weight}`, height: `${latestHeight.height} ${units.length}` })
                : t("general.noData")}
            </div>
          </div>
        </div>}
      </div>

      {/* Activity averages over the trailing 30 days */}
      {(isFeatureEnabled("feeding") || isFeatureEnabled("sleep")) && (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: 14,
            marginBottom: 20,
          }}
        >
          {isFeatureEnabled("feeding") && (
            <div className="fade-in fade-in-5">
              <StatCard
                icon={<Icons.Bottle />}
                label={t("growth.avgFeeding")}
                value={avgFeeding ? `${avgFeeding} ${units.volume}` : "—"}
                color={colors.feeding}
                sub={
                  <>
                    <div>{t("growth.perDay30d")}</div>
                    {feedingGap !== null && (
                      <div>{t("growth.avgGap", { value: formatHoursMinutes(feedingGap) })}</div>
                    )}
                    {breastDuration !== null && (
                      <div>{t("growth.avgBreastDuration", { value: formatHoursMinutes(breastDuration) })}</div>
                    )}
                  </>
                }
              />
            </div>
          )}

          {isFeatureEnabled("sleep") && (
            <div className="fade-in fade-in-5">
              <StatCard
                icon={<Icons.Moon />}
                label={t("growth.avgSleep")}
                value={avgSleep ? `${avgSleep}h` : "—"}
                color={colors.sleep}
                sub={t("growth.perDay30d")}
              />
            </div>
          )}
        </div>
      )}

      {/* Charts */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
          gap: 16,
        }}
      >
        {/* Daily Feeding Totals */}
        {isFeatureEnabled("feeding") && <div className="fade-in fade-in-5">
          <SectionCard title={t("growth.dailyFeeding30d")} icon={<Icons.Bottle />} color={colors.feeding}>
            {feedingSeries.some((d) => d.amount > 0) ? (
              <>
                <div style={{ height: 200 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={feedingSeries} onClick={(data) => handleChartClick(data, "feeding", feedingSeries, "amount")}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#252836" vertical={false} />
                      <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                      <YAxis tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} />
                      <Tooltip content={<CustomTooltip />} />
                      <Area
                        type="monotone"
                        dataKey="amount"
                        stroke={colors.feeding}
                        strokeWidth={2}
                        fill={`${colors.feeding}30`}
                        dot={false}
                        activeDot={{ r: 4, fill: colors.feeding, cursor: "pointer" }}
                        cursor="pointer"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                {selectedBar?.type === "feeding" && (
                  <ChartDetailBar
                    label={selectedBar.label}
                    value={selectedBar.value}
                    unit={units.volume}
                    color={colors.feeding}
                    onViewEntries={() => openDayModal(selectedBar.label, "feeding")}
                    onDismiss={() => setSelectedBar(null)}
                  />
                )}
              </>
            ) : (
              <div style={{ color: "var(--text-dim)", fontSize: 13, textAlign: "center", padding: 40 }}>
                {t("growth.noData", { type: "feeding" })}
              </div>
            )}
          </SectionCard>
        </div>}

        {/* Daily Feeding Counts by Type */}
        {isFeatureEnabled("feeding") && <div className="fade-in fade-in-6">
          <SectionCard title={t("growth.dailyFeedingCount30d")} icon={<Icons.Bottle />} color={colors.feeding}>
            {feedingCountSeries.some((d) => FEEDING_COUNT_KEYS.some((k) => d[k] > 0)) ? (
              <div style={{ height: 200 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={feedingCountSeries}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#252836" vertical={false} />
                    <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                    <YAxis tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} allowDecimals={false} />
                    <Tooltip content={<CustomTooltip />} />
                    {FEEDING_COUNT_KEYS.map((key) => (
                      <Bar
                        key={key}
                        dataKey={key}
                        stackId="feed"
                        fill={feedingCountFills[key] || feedingCountFills.other}
                        name={t(feedingCountLabelKeys[key])}
                      />
                    ))}
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div style={{ color: "var(--text-dim)", fontSize: 13, textAlign: "center", padding: 40 }}>
                {t("growth.noData", { type: "feeding" })}
              </div>
            )}
          </SectionCard>
        </div>}

        {/* Daily Sleep Totals */}
        {isFeatureEnabled("sleep") && <div className="fade-in fade-in-7">
          <SectionCard title={t("growth.dailySleep30d")} icon={<Icons.Moon />} color={colors.sleep}>
            {sleepSeries.some((d) => d.hours > 0) ? (
              <>
                <div style={{ height: 200 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={sleepSeries} onClick={(data) => handleChartClick(data, "sleep", sleepSeries, "hours")}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#252836" vertical={false} />
                      <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                      <YAxis tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} />
                      <Tooltip content={<CustomTooltip />} />
                      <Area
                        type="monotone"
                        dataKey="hours"
                        stroke={colors.sleep}
                        strokeWidth={2}
                        fill={`${colors.sleep}30`}
                        dot={false}
                        activeDot={{ r: 4, fill: colors.sleep, cursor: "pointer" }}
                        cursor="pointer"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                {selectedBar?.type === "sleep" && (
                  <ChartDetailBar
                    label={selectedBar.label}
                    value={selectedBar.value}
                    unit="h"
                    color={colors.sleep}
                    onViewEntries={() => openDayModal(selectedBar.label, "sleep")}
                    onDismiss={() => setSelectedBar(null)}
                  />
                )}
              </>
            ) : (
              <div style={{ color: "var(--text-dim)", fontSize: 13, textAlign: "center", padding: 40 }}>
                {t("growth.noData", { type: "sleep" })}
              </div>
            )}
          </SectionCard>
        </div>}

        {/* Daily Sleep Counts */}
        {isFeatureEnabled("sleep") && <div className="fade-in fade-in-7">
          <SectionCard title={t("growth.dailySleepCount30d")} icon={<Icons.Moon />} color={colors.sleep}>
            {sleepCountSeries.some((d) => d.count > 0) ? (
              <>
                <div style={{ height: 200 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={sleepCountSeries} onClick={(data) => handleChartClick(data, "sleepCount", sleepCountSeries, "count")}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#252836" vertical={false} />
                      <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                      <YAxis tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} allowDecimals={false} />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar dataKey="count" fill={colors.sleep} radius={[4, 4, 0, 0]} opacity={0.85} cursor="pointer" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                {selectedBar?.type === "sleepCount" && (
                  <ChartDetailBar
                    label={selectedBar.label}
                    value={selectedBar.value}
                    unit={selectedBar.value === 1 ? t("growth.session") : t("growth.sessions")}
                    color={colors.sleep}
                    onViewEntries={() => openDayModal(selectedBar.label, "sleep")}
                    onDismiss={() => setSelectedBar(null)}
                  />
                )}
              </>
            ) : (
              <div style={{ color: "var(--text-dim)", fontSize: 13, textAlign: "center", padding: 40 }}>
                {t("growth.noData", { type: "sleep" })}
              </div>
            )}
          </SectionCard>
        </div>}

        {/* Daily Pumping Totals — data-gated like the Overview card so
            families who don't pump aren't stuck with an empty chart */}
        {isFeatureEnabled("pumping") && pumpingSeries.some((d) => d.amount > 0) && <div className="fade-in fade-in-7">
          <SectionCard title={t("growth.dailyPumping30d")} icon={<Icons.Bottle />} color={colors.pumping}>
            <>
              <div style={{ height: 200 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={pumpingSeries} onClick={(data) => handleChartClick(data, "pumping", pumpingSeries, "amount")}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#252836" vertical={false} />
                    <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                    <YAxis tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area
                      type="monotone"
                      dataKey="amount"
                      stroke={colors.pumping}
                      strokeWidth={2}
                      fill={`${colors.pumping}30`}
                      dot={false}
                      activeDot={{ r: 4, fill: colors.pumping, cursor: "pointer" }}
                      cursor="pointer"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              {selectedBar?.type === "pumping" && (
                <ChartDetailBar
                  label={selectedBar.label}
                  value={selectedBar.value}
                  unit={units.volume}
                  color={colors.pumping}
                  onViewEntries={() => openDayModal(selectedBar.label, "pumping")}
                  onDismiss={() => setSelectedBar(null)}
                />
              )}
            </>
          </SectionCard>
        </div>}

        {/* Daily Pumping Counts — gated on sessions rather than amounts so
            it still shows for entries logged without an amount */}
        {isFeatureEnabled("pumping") && pumpingCountSeries.some((d) => d.count > 0) && <div className="fade-in fade-in-7">
          <SectionCard title={t("growth.dailyPumpingCount30d")} icon={<Icons.Bottle />} color={colors.pumping}>
            <>
              <div style={{ height: 200 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={pumpingCountSeries} onClick={(data) => handleChartClick(data, "pumpingCount", pumpingCountSeries, "count")}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#252836" vertical={false} />
                    <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                    <YAxis tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} allowDecimals={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="count" fill={colors.pumping} radius={[4, 4, 0, 0]} opacity={0.85} cursor="pointer" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              {selectedBar?.type === "pumpingCount" && (
                <ChartDetailBar
                  label={selectedBar.label}
                  value={selectedBar.value}
                  unit={selectedBar.value === 1 ? t("growth.session") : t("growth.sessions")}
                  color={colors.pumping}
                  onViewEntries={() => openDayModal(selectedBar.label, "pumping")}
                  onDismiss={() => setSelectedBar(null)}
                />
              )}
            </>
          </SectionCard>
        </div>}

        {/* Weight Chart */}
        {isFeatureEnabled("weight") && <div className="fade-in fade-in-8">
          <SectionCard
            title={t("growth.weightTrend")}
            icon={<Icons.Weight />}
            color={colors.growth}
            action={canShowWHO ? <WHOToggle on={whoView.weight} onToggle={() => setWhoView(v => ({ ...v, weight: !v.weight }))} /> : null}
          >
            {whoView.weight && canShowWHO ? (
              <WHOGrowthChart metric="weight" sex={sex} birthDate={birthDate} entries={weights} valueField="weight" unit={units.weight} color={colors.growth} />
            ) : weightSeries.length >= 2 ? (
              <>
                <div style={{ height: 200 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={weightSeries} onClick={(data) => handleChartClick(data, "weight", weightSeries, "weight")}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#252836" vertical={false} />
                      <XAxis dataKey="timestamp" type="number" scale="time" domain={["dataMin", "dataMax"]} tickFormatter={formatGrowthTick} tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} domain={["auto", "auto"]} />
                      <Tooltip content={<CustomTooltip labelFormatter={formatGrowthTick} />} />
                      <Line
                        type="monotone"
                        dataKey="weight"
                        stroke={colors.growth}
                        strokeWidth={2.5}
                        dot={{ fill: colors.growth, r: 4, cursor: "pointer" }}
                        activeDot={{ r: 6, cursor: "pointer" }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                {selectedBar?.type === "weight" && (
                  <ChartDetailBar
                    label={formatGrowthTick(selectedBar.label)}
                    value={selectedBar.value}
                    unit={units.weight}
                    color={colors.growth}
                    actionLabel={t("general.edit")}
                    onViewEntries={() => {
                      if (selectedBar.entry) onEditEntry?.("weight", selectedBar.entry);
                      setSelectedBar(null);
                    }}
                    onDismiss={() => setSelectedBar(null)}
                  />
                )}
              </>
            ) : (
              <div style={{ color: "var(--text-dim)", fontSize: 13, textAlign: "center", padding: 40 }}>
                {weightSeries.length === 1 ? t("growth.needTwoMeasurements") : t("growth.noData", { type: "weight" })}
              </div>
            )}
          </SectionCard>
        </div>}

        {/* Height Chart */}
        {isFeatureEnabled("height") && <div className="fade-in fade-in-9">
          <SectionCard
            title={t("growth.heightTrend")}
            icon={<Icons.Ruler />}
            color={colors.height}
            action={canShowWHO ? <WHOToggle on={whoView.height} onToggle={() => setWhoView(v => ({ ...v, height: !v.height }))} /> : null}
          >
            {whoView.height && canShowWHO ? (
              <WHOGrowthChart metric="height" sex={sex} birthDate={birthDate} entries={heights} valueField="height" unit={units.length} color={colors.height} />
            ) : heightSeries.length >= 2 ? (
              <>
                <div style={{ height: 200 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={heightSeries} onClick={(data) => handleChartClick(data, "height", heightSeries, "height")}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#252836" vertical={false} />
                      <XAxis dataKey="timestamp" type="number" scale="time" domain={["dataMin", "dataMax"]} tickFormatter={formatGrowthTick} tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} domain={["auto", "auto"]} />
                      <Tooltip content={<CustomTooltip labelFormatter={formatGrowthTick} />} />
                      <Line
                        type="monotone"
                        dataKey="height"
                        stroke={colors.height}
                        strokeWidth={2.5}
                        dot={{ fill: colors.height, r: 4, cursor: "pointer" }}
                        activeDot={{ r: 6, cursor: "pointer" }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                {selectedBar?.type === "height" && (
                  <ChartDetailBar
                    label={formatGrowthTick(selectedBar.label)}
                    value={selectedBar.value}
                    unit={units.length}
                    color={colors.height}
                    actionLabel={t("general.edit")}
                    onViewEntries={() => {
                      if (selectedBar.entry) onEditEntry?.("height", selectedBar.entry);
                      setSelectedBar(null);
                    }}
                    onDismiss={() => setSelectedBar(null)}
                  />
                )}
              </>
            ) : (
              <div style={{ color: "var(--text-dim)", fontSize: 13, textAlign: "center", padding: 40 }}>
                {heightSeries.length === 1 ? t("growth.needTwoMeasurements") : t("growth.noData", { type: "height" })}
              </div>
            )}
          </SectionCard>
        </div>}
        {/* Head Circumference Chart */}
        {isFeatureEnabled("headcirc") && <div className="fade-in fade-in-10">
          <SectionCard
            title={t("growth.headCircTrend")}
            icon={<Icons.Baby />}
            color={colors.growth}
            action={canShowWHO ? <WHOToggle on={whoView.headcirc} onToggle={() => setWhoView(v => ({ ...v, headcirc: !v.headcirc }))} /> : null}
          >
            {whoView.headcirc && canShowWHO ? (
              <WHOGrowthChart metric="headcirc" sex={sex} birthDate={birthDate} entries={headCircumferences} valueField="head_circumference" unit={units.length} color={colors.growth} />
            ) : headCircSeries.length >= 2 ? (
              <>
                <div style={{ height: 200 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={headCircSeries} onClick={(data) => handleChartClick(data, "headcirc", headCircSeries, "head_circumference")}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#252836" vertical={false} />
                      <XAxis dataKey="timestamp" type="number" scale="time" domain={["dataMin", "dataMax"]} tickFormatter={formatGrowthTick} tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} domain={["auto", "auto"]} />
                      <Tooltip content={<CustomTooltip labelFormatter={formatGrowthTick} />} />
                      <Line type="monotone" dataKey="head_circumference" stroke={colors.growth} strokeWidth={2.5} dot={{ fill: colors.growth, r: 4, cursor: "pointer" }} activeDot={{ r: 6, cursor: "pointer" }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                {selectedBar?.type === "headcirc" && (
                  <ChartDetailBar
                    label={formatGrowthTick(selectedBar.label)}
                    value={selectedBar.value}
                    unit={units.length}
                    color={colors.growth}
                    actionLabel={t("general.edit")}
                    onViewEntries={() => {
                      if (selectedBar.entry) onEditEntry?.("headcirc", selectedBar.entry);
                      setSelectedBar(null);
                    }}
                    onDismiss={() => setSelectedBar(null)}
                  />
                )}
              </>
            ) : (
              <div style={{ color: "var(--text-dim)", fontSize: 13, textAlign: "center", padding: 40 }}>
                {headCircSeries.length === 1 ? t("growth.needTwoMeasurements") : t("growth.noData", { type: "head circumference" })}
              </div>
            )}
          </SectionCard>
        </div>}

        {/* BMI Chart */}
        {isFeatureEnabled("bmi") && <div className="fade-in fade-in-11">
          <SectionCard
            title={t("growth.bmiTrend")}
            icon={<Icons.TrendUp />}
            color={colors.feeding}
            action={canShowWHO ? <WHOToggle on={whoView.bmi} onToggle={() => setWhoView(v => ({ ...v, bmi: !v.bmi }))} /> : null}
          >
            {whoView.bmi && canShowWHO ? (
              <WHOGrowthChart
                metric="bmi"
                sex={sex}
                birthDate={birthDate}
                entries={bmiSeries.map((p) => ({ date: p.dateStr, bmi: p.bmi }))}
                valueField="bmi"
                unit="kg/m²"
                color={colors.feeding}
              />
            ) : bmiSeries.length >= 2 ? (
              <div style={{ height: 200 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={bmiSeries}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#252836" vertical={false} />
                    <XAxis dataKey="timestamp" type="number" scale="time" domain={["dataMin", "dataMax"]} tickFormatter={formatGrowthTick} tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: "#5A6178" }} axisLine={false} tickLine={false} domain={["auto", "auto"]} />
                    <Tooltip content={<CustomTooltip labelFormatter={formatGrowthTick} />} />
                    <Line type="monotone" dataKey="bmi" stroke={colors.feeding} strokeWidth={2.5} dot={{ fill: colors.feeding, r: 4 }} activeDot={{ r: 6 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div style={{ color: "var(--text-dim)", fontSize: 13, textAlign: "center", padding: 40 }}>
                {bmiSeries.length === 1 ? t("growth.needTwoMeasurements") : t("growth.noData", { type: "BMI" })}
              </div>
            )}
          </SectionCard>
        </div>}
      </div>

      {dayModal && (
        <DayActivitiesModal
          day={dayModal.day}
          type={dayModal.type}
          data={dayModal.data}
          onEditEntry={onEditEntry}
          onClose={() => setDayModal(null)}
        />
      )}
    </>
  );
}

function WHOToggle({ on, onToggle }) {
  const { t } = useI18n();
  return (
    <button
      onClick={onToggle}
      title={t("growth.whoTooltip")}
      style={{
        fontSize: 11,
        fontWeight: 500,
        padding: "4px 10px",
        borderRadius: 6,
        border: "1px solid var(--border)",
        background: on ? "#6C5CE7" : "var(--card-bg)",
        color: on ? "white" : "var(--text-muted)",
        cursor: "pointer",
        fontFamily: "inherit",
      }}
    >
      {on ? t("growth.whoOn") : t("growth.whoOff")}
    </button>
  );
}
