import { useState, useEffect, useCallback, useRef } from "react";
import { api } from "../api";
import { getMockData } from "../utils/mockData";
import { localInputToUTC } from "../utils/datetime";

function toLocalISODate(date) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function fixChildPicture(c) {
  if (c?.picture) {
    // If it's already a relative API path, leave as-is
    if (c.picture.startsWith("./api/") || c.picture.startsWith("/api/")) {
      return c;
    }
    // Cache-bust with updated_at or current time
    const cb = c.updated_at ? new Date(c.updated_at).getTime() : Date.now();
    try {
      // Handle absolute URLs (legacy Baby Buddy format)
      const url = new URL(c.picture);
      c.picture = `./api/media${url.pathname}?v=${cb}`;
    } catch {
      // Assume it's a filename, build the API path
      if (c.picture && !c.picture.startsWith("http")) {
        c.picture = `./api/media/photos/${c.picture}?size=thumb&v=${cb}`;
      }
    }
  }
  return c;
}

const emptyPage = { results: [], count: 0 };

// `milkStockEnabled` gates two extra requests (the week's uneaten-milk rows and
// the all-time stash balance). It's a per-device preference that defaults off,
// and this hook already fires 20+ requests per poll, so households that don't
// track a stash shouldn't pay for it.
export function useBabyData(canReadFn, { milkStockEnabled = false } = {}) {
  const canReadRef = useRef(canReadFn || (() => true));
  canReadRef.current = canReadFn || (() => true);
  const milkStockRef = useRef(milkStockEnabled);
  milkStockRef.current = milkStockEnabled;
  const [children, setChildren] = useState([]);
  const [child, setChild] = useState(null);
  const [feedings, setFeedings] = useState([]);
  const [weeklyFeedings, setWeeklyFeedings] = useState([]);
  const [sleepEntries, setSleepEntries] = useState([]);
  const [weeklySleep, setWeeklySleep] = useState([]);
  const [changes, setChanges] = useState([]);
  const [weeklyChanges, setWeeklyChanges] = useState([]);
  const [tummyTimes, setTummyTimes] = useState([]);
  const [weeklyTummyTimes, setWeeklyTummyTimes] = useState([]);
  const [pumpingSessions, setPumpingSessions] = useState([]);
  const [weeklyPumping, setWeeklyPumping] = useState([]);
  const [temperatures, setTemperatures] = useState([]);
  const [weights, setWeights] = useState([]);
  const [heights, setHeights] = useState([]);
  const [monthlyFeedings, setMonthlyFeedings] = useState([]);
  const [monthlySleep, setMonthlySleep] = useState([]);
  const [monthlyPumping, setMonthlyPumping] = useState([]);
  const [notes, setNotes] = useState([]);
  const [timers, setTimers] = useState([]);
  const [headCircumferences, setHeadCircumferences] = useState([]);
  const [medications, setMedications] = useState([]);
  const [milestones, setMilestones] = useState([]);
  const [bmiEntries, setBmiEntries] = useState([]);
  const [weeklyMilkWaste, setWeeklyMilkWaste] = useState([]);
  const [milkStock, setMilkStock] = useState(null);
  // Per-entity-type tag maps: `tagMaps[entityType][entity_id] = [tag...]`.
  // Populated from the /api/tags/bulk endpoint on every refresh so list
  // views can render tag chips without N+1 fetches.
  const [tagMaps, setTagMaps] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastSync, setLastSync] = useState(null);
  const [unitSystem, setUnitSystem] = useState(
    () => localStorage.getItem("babytracker_units") || "metric"
  );
  const changeUnitSystem = useCallback((system) => {
    try { localStorage.setItem("babytracker_units", system); } catch { /* private mode */ }
    setUnitSystem(system);
  }, []);
  const intervalRef = useRef(null);
  const childIdRef = useRef(null);
  const fetchSeqRef = useRef(0);

  const fetchData = useCallback(async (childId) => {
    // Concurrent fetches happen: the 30s background refresh can overlap a
    // manual child switch, and slow responses can arrive out of order. Only
    // the most recently started fetch may apply its results — a stale
    // response would clobber the dashboard with the previous child's data.
    const seq = ++fetchSeqRef.current;
    const stale = () => seq !== fetchSeqRef.current;
    try {
      const now = new Date();

      // Filter bounds are built in the user's local wall-clock (what "today"
      // means to them) but the backend's DB session runs in UTC, so every
      // filter string is converted to its UTC-equivalent naive instant
      // before being sent. Without this, "today 00:00 local" got read as
      // "today 00:00 UTC" on the server and cut off entries by the user's
      // UTC offset at the day boundaries.
      const todayStr = toLocalISODate(now);
      const todayMin = localInputToUTC(`${todayStr}T00:00:00`);
      const todayMax = localInputToUTC(`${todayStr}T23:59:59`);

      // Sleep entries can span the rolling 24h window boundary, and the API
      // only filters by start_time. To make sure the OverviewTab "Last 24h"
      // total — which clips each entry to the window — sees overnight sleeps
      // that started *before* the window but ended inside it, we ask for a
      // wider lookback (~36h). Anything fully outside the window contributes
      // 0 hours after the clip, so the wider fetch is harmless to the stat.
      const sleepFetchAgo = new Date(now.getTime() - 36 * 60 * 60 * 1000);
      const sleepMin = localInputToUTC(
        `${toLocalISODate(sleepFetchAgo)}T${String(sleepFetchAgo.getHours()).padStart(2, "0")}:${String(sleepFetchAgo.getMinutes()).padStart(2, "0")}:00`,
      );

      const weekAgo = new Date(now);
      weekAgo.setDate(weekAgo.getDate() - 6);
      const weekMin = localInputToUTC(`${toLocalISODate(weekAgo)}T00:00:00`);
      // Sleep charts now clip overnight entries to day boundaries, so the
      // fetch must reach 1 day earlier to capture sleeps that started the
      // evening before the chart range but ended inside it.
      const weekSleepAgo = new Date(now);
      weekSleepAgo.setDate(weekSleepAgo.getDate() - 7);
      const weekSleepMin = localInputToUTC(`${toLocalISODate(weekSleepAgo)}T00:00:00`);

      const monthAgo = new Date(now);
      monthAgo.setDate(monthAgo.getDate() - 29);
      const monthMin = localInputToUTC(`${toLocalISODate(monthAgo)}T00:00:00`);
      const monthSleepAgo = new Date(now);
      monthSleepAgo.setDate(monthSleepAgo.getDate() - 30);
      const monthSleepMin = localInputToUTC(`${toLocalISODate(monthSleepAgo)}T00:00:00`);

      const c = childId || undefined;

      const [
        feedingsRes,
        weeklyFeedingsRes,
        sleepRes,
        weeklySleepRes,
        changesRes,
        weeklyChangesRes,
        tummyRes,
        weeklyTummyRes,
        pumpingRes,
        weeklyPumpingRes,
        tempRes,
        weightRes,
        heightRes,
        timersRes,
        notesRes,
        monthlyFeedingsRes,
        monthlySleepRes,
        monthlyPumpingRes,
        headCircRes,
        medicationsRes,
        milestonesRes,
        bmiRes,
        milkWasteRes,
        milkStockRes,
      ] = await Promise.all((() => {
        // Only fetch data for features the user can read.
        //
        // `call` is a thunk, not a promise. Passing the promise directly meant
        // the request was issued while evaluating the argument, before this
        // function could decide to skip it — so a restricted user still sent
        // every request and merely discarded the results.
        const ep = emptyPage;
        const q = (feature, call) => canReadRef.current(feature) ? call() : Promise.resolve(ep);
        // Uneaten milk rides on the pumping permission (see the note in
        // internal/models/access.go) and is additionally gated on the
        // per-device milk-stock preference.
        const stockOn = milkStockRef.current && canReadRef.current("pumping");
        return [
        q("feeding", () => api.getFeedings({ child: c, start_min: todayMin, start_max: todayMax, limit: 100, ordering: "-start" })),
        q("feeding", () => api.getFeedings({ child: c, start_min: weekMin, limit: 200, ordering: "-start" })),
        q("sleep", () => api.getSleep({ child: c, start_min: sleepMin, limit: 100, ordering: "-start" })),
        q("sleep", () => api.getSleep({ child: c, start_min: weekSleepMin, limit: 200, ordering: "-start" })),
        q("diaper", () => api.getChanges({ child: c, date_min: todayMin, date_max: todayMax, limit: 100, ordering: "-time" })),
        // Diapers were the one type fetched for today only, so just after
        // midnight the card had nothing to report a "last change" from.
        q("diaper", () => api.getChanges({ child: c, date_min: weekMin, limit: 200, ordering: "-time" })),
        q("tummy", () => api.getTummyTimes({ child: c, start_min: todayMin, start_max: todayMax, limit: 100, ordering: "-start" })),
        q("tummy", () => api.getTummyTimes({ child: c, start_min: weekMin, limit: 200, ordering: "-start" })),
        q("pumping", () => api.getPumping({ child: c, start_min: todayMin, start_max: todayMax, limit: 100, ordering: "-start" })),
        q("pumping", () => api.getPumping({ child: c, start_min: weekMin, limit: 200, ordering: "-start" })),
        q("temp", () => api.getTemperature({ child: c, limit: 10, ordering: "-time" })),
        q("weight", () => api.getWeight({ child: c, limit: 20, ordering: "-date" })),
        q("height", () => api.getHeight({ child: c, limit: 20, ordering: "-date" })),
        q("feeding", () => api.getTimers()),
        q("note", () => api.getNotes({ child: c, limit: 20, ordering: "-time" })),
        q("feeding", () => api.getFeedings({ child: c, start_min: monthMin, limit: 500, ordering: "-start" })),
        q("sleep", () => api.getSleep({ child: c, start_min: monthSleepMin, limit: 500, ordering: "-start" })),
        q("pumping", () => api.getPumping({ child: c, start_min: monthMin, limit: 500, ordering: "-start" })),
        q("headcirc", () => api.getHeadCircumference({ child: c, limit: 20, ordering: "-date" })),
        q("medication", () => api.getMedications({ child: c, limit: 20, ordering: "-time" })),
        q("milestone", () => api.getMilestones({ child: c, limit: 50, ordering: "-date" })),
        q("bmi", () => api.getBMI({ child: c, limit: 20, ordering: "-date" })),
        stockOn ? api.getMilkWaste({ child: c, date_min: weekMin, limit: 200, ordering: "-time" }) : Promise.resolve(ep),
        // Whole-history aggregate, so it can't be derived from the windows
        // above. Null (not an empty page) when off, which is what the card
        // reads as "no balance to show".
        stockOn && c ? api.getMilkStock(c) : Promise.resolve(null),
        ];
      })());

      if (stale()) return;

      setFeedings(feedingsRes.results || []);
      setWeeklyFeedings(weeklyFeedingsRes.results || []);
      setSleepEntries(sleepRes.results || []);
      setWeeklySleep(weeklySleepRes.results || []);
      setChanges(changesRes.results || []);
      setWeeklyChanges(weeklyChangesRes.results || []);
      setTummyTimes(tummyRes.results || []);
      setWeeklyTummyTimes(weeklyTummyRes.results || []);
      setPumpingSessions(pumpingRes.results || []);
      setWeeklyPumping(weeklyPumpingRes.results || []);
      setTemperatures(tempRes.results || []);
      setWeights(weightRes.results || []);
      setHeights(heightRes.results || []);
      setTimers(timersRes.results || []);
      setNotes(notesRes.results || []);
      setMonthlyFeedings(monthlyFeedingsRes.results || []);
      setMonthlySleep(monthlySleepRes.results || []);
      setMonthlyPumping(monthlyPumpingRes.results || []);
      setHeadCircumferences(headCircRes.results || []);
      setMedications(medicationsRes.results || []);
      setMilestones(milestonesRes.results || []);
      setBmiEntries(bmiRes.results || []);
      setWeeklyMilkWaste(milkWasteRes.results || []);
      setMilkStock(milkStockRes);

      // Fetch tag maps for every taggable entity type in parallel. Each
      // returns `{ "<entity_id>": [tag, tag, ...] }`; we only populate
      // entries that actually have tags (untagged entities are absent).
      // A failure here shouldn't break the dashboard — fall back to empty
      // for the affected type — but we log so a partial outage doesn't
      // silently drop tags off the UI with no signal to the operator.
      const tagTypes = [
        "feeding", "sleep", "diaper", "tummy_time", "pumping",
        "temperature", "medication", "note", "milestone",
        "weight", "height", "head_circumference", "bmi",
      ];
      try {
        const results = await Promise.all(
          tagTypes.map((t) =>
            api.getEntityTagsBulk(t).catch((e) => {
              console.warn(`tag fetch failed for ${t}:`, e);
              return {};
            }),
          ),
        );
        if (stale()) return;
        const nextMaps = {};
        tagTypes.forEach((t, i) => { nextMaps[t] = results[i] || {}; });
        setTagMaps(nextMaps);
      } catch (err) {
        console.warn("tag bulk fetch aggregate failure:", err);
        if (!stale()) setTagMaps({});
      }

      if (stale()) return;
      setLastSync(new Date());
      setError(null);
    } catch (err) {
      if (!stale()) setError(err.message);
    } finally {
      // A stale fetch must not touch `loading` either: the newer fetch that
      // superseded it owns the spinner and will clear it when *it* finishes.
      if (!stale()) setLoading(false);
    }
  }, []);

  const fetchAll = useCallback(async () => {
    try {
      const childrenRes = await api.getChildren();
      const allChildren = (childrenRes.results || []).map(fixChildPicture);
      setChildren(allChildren);

      const active = allChildren.find((c) => c.id === childIdRef.current) || allChildren[0] || null;
      if (active) {
        childIdRef.current = active.id;
        setChild(active);
      }

      await fetchData(active?.id);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  }, [fetchData]);

  const selectChild = useCallback(
    (id) => {
      const selected = children.find((c) => c.id === id);
      if (!selected || selected.id === child?.id) return;
      childIdRef.current = id;
      setChild(selected);
      setLoading(true);
      fetchData(id);
    },
    [children, child, fetchData]
  );

  const loadMock = useCallback(() => {
    const mock = getMockData();
    setChildren(mock.children);
    setChild(mock.children[0]);
    childIdRef.current = mock.children[0].id;
    setFeedings(mock.feedings);
    setWeeklyFeedings(mock.weeklyFeedings);
    setSleepEntries(mock.sleepEntries);
    setWeeklySleep(mock.weeklySleep);
    setChanges(mock.changes);
    setTummyTimes(mock.tummyTimes);
    setWeeklyTummyTimes(mock.weeklyTummyTimes);
    setTemperatures(mock.temperatures);
    setWeights(mock.weights);
    setHeights(mock.heights);
    setTimers(mock.timers);
    setNotes(mock.notes);
    setMonthlyFeedings(mock.monthlyFeedings);
    setMonthlySleep(mock.monthlySleep);
    setLastSync(new Date());
    setLoading(false);
  }, []);

  const selectMockChild = useCallback(
    (id) => {
      const selected = children.find((c) => c.id === id);
      if (!selected || selected.id === child?.id) return;
      childIdRef.current = id;
      setChild(selected);
      const mock = getMockData(id);
      setFeedings(mock.feedings);
      setWeeklyFeedings(mock.weeklyFeedings);
      setSleepEntries(mock.sleepEntries);
      setWeeklySleep(mock.weeklySleep);
      setChanges(mock.changes);
      setTummyTimes(mock.tummyTimes);
      setWeeklyTummyTimes(mock.weeklyTummyTimes);
      setTemperatures(mock.temperatures);
      setWeights(mock.weights);
      setHeights(mock.heights);
      setTimers(mock.timers);
      setNotes(mock.notes);
      setMonthlyFeedings(mock.monthlyFeedings);
      setMonthlySleep(mock.monthlySleep);
    },
    [children, child]
  );

  const demoRef = useRef(false);

  useEffect(() => {
    api
      .getConfig()
      .then((cfg) => {
        const savedUnits = localStorage.getItem("babytracker_units");
        if (savedUnits) {
          setUnitSystem(savedUnits);
        } else if (cfg.unit_system) {
          setUnitSystem(cfg.unit_system);
        }
        if (cfg.demo_mode) {
          demoRef.current = true;
          loadMock();
        } else {
          fetchAll();
          const ms = (cfg.refresh_interval || 30) * 1000;
          intervalRef.current = setInterval(fetchAll, ms);
        }
      })
      .catch(() => {
        fetchAll();
        intervalRef.current = setInterval(fetchAll, 30000);
      });

    return () => clearInterval(intervalRef.current);
  }, [fetchAll, loadMock]);

  return {
    children,
    child,
    selectChild: demoRef.current ? selectMockChild : selectChild,
    feedings,
    weeklyFeedings,
    sleepEntries,
    weeklySleep,
    changes,
    weeklyChanges,
    tummyTimes,
    weeklyTummyTimes,
    pumpingSessions,
    weeklyPumping,
    temperatures,
    weights,
    heights,
    monthlyFeedings,
    monthlySleep,
    monthlyPumping,
    notes,
    timers,
    headCircumferences,
    medications,
    milestones,
    bmiEntries,
    weeklyMilkWaste,
    milkStock,
    tagMaps,
    loading,
    error,
    lastSync,
    unitSystem,
    // Saves this device's unit preference and relabels values right away.
    setUnitSystem: changeUnitSystem,
    // In demo mode refetch must not hit the API — otherwise the
    // post-permissions refetch effect in App.jsx fires /api/children,
    // 404s against the demo router, and surfaces a "Connection error"
    // banner on a page that otherwise has no connection to error about.
    refetch: demoRef.current ? loadMock : fetchAll,
  };
}
