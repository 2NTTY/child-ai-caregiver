export const FIXED_NOW = '2026-11-11T23:30:00.000Z';

// Wall-clock only. Browser timers and performance.now remain native for charts.
export function makeFixedDate(NativeDate) {
  const epoch = NativeDate.parse(FIXED_NOW);
  const normalize = (v) => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?$/.test(v) ? `${v}Z` : v;
  const locale = (v) => !v || (Array.isArray(v) && !v.length) ? 'en-US' : v;
  class FixedDate extends NativeDate {
    constructor(...args) {
      super(...(args.length === 0 ? [epoch] : args.length > 1 ? [NativeDate.UTC(...args)] : [normalize(args[0])]));
    }
    static now() { return epoch; }
    static parse(value) { return NativeDate.parse(normalize(value)); }
    getTimezoneOffset() { return 0; }
    toLocaleDateString(loc, options) { return super.toLocaleDateString(locale(loc), {timeZone:'UTC',...options}); }
    toLocaleTimeString(loc, options) { return super.toLocaleTimeString(locale(loc), {timeZone:'UTC',...options}); }
    toLocaleString(loc, options) { return super.toLocaleString(locale(loc), {timeZone:'UTC',...options}); }
  }
  for (const suffix of ['FullYear','Month','Date','Day','Hours','Minutes','Seconds','Milliseconds']) {
    FixedDate.prototype[`get${suffix}`] = NativeDate.prototype[`getUTC${suffix}`];
  }
  for (const suffix of ['FullYear','Month','Date','Hours','Minutes','Seconds','Milliseconds']) {
    FixedDate.prototype[`set${suffix}`] = NativeDate.prototype[`setUTC${suffix}`];
  }
  return FixedDate;
}
