import {makeFixedDate} from './clock.mjs';import {installOfflineGuard} from './offline.mjs';import {installMemoryStorage} from './storage.mjs';
installMemoryStorage(window);installOfflineGuard(window);window.Date=makeFixedDate(window.Date);
await import('../upstream/frontend/src/main.jsx');
