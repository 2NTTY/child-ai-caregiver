from pathlib import Path
import json, shutil

ROOT = Path(__file__).resolve().parent.parent
FRONT = ROOT / 'upstream/frontend'
OUT = ROOT / 'public'
DEST = OUT / 'licenses'
DEST.mkdir(exist_ok=True)
shutil.copy2(ROOT/'upstream/LICENSE', DEST/'BabyTracker-MIT.txt')
for family in ['dmsans', 'jetbrainsmono']:
    shutil.copy2(ROOT/'fonts/ofl'/family/'OFL.txt', DEST/(family+'-OFL.txt'))
graph=json.loads((ROOT/'evidence/module-graph.json').read_text())
included=set()
for module in graph['module_ids']:
    if 'node_modules/' in module:
        parts=module.split('node_modules/',1)[1].split('/')
        included.add('/'.join(parts[:2]) if parts[0].startswith('@') else parts[0])
metadata=[]
for name in sorted(included):
    pkg=FRONT/'node_modules'/name
    info=json.loads((pkg/'package.json').read_text())
    licenses=[]
    for file in pkg.iterdir():
        if file.is_file() and file.name.upper().startswith(('LICENSE','LICENCE','COPYING','NOTICE')):
            output=name.replace('/','__')+'__'+file.name
            shutil.copy2(file,DEST/output)
            licenses.append(output)
    if name=='victory-vendor':
        output='victory-vendor__LICENSE.txt'
        shutil.copy2(ROOT/'evidence/victory-LICENSE.txt',DEST/output)
        licenses.append(output)
    if not licenses: raise RuntimeError('Missing license for '+name)
    metadata.append({'name':name,'version':info['version'],'license':info.get('license'),'files':licenses})
for path in [ROOT/'evidence/bundled-dependencies.json',DEST/'DEPENDENCIES.json']:
    path.write_text(json.dumps(metadata,indent=2)+'\n')
shutil.copy2(ROOT/'fixtures/provenance.json',OUT/'FIXTURE-PROVENANCE.json')
shutil.copy2(ROOT/'DISPLAY-README.md',OUT/'README.md')
shutil.copy2(ROOT/'PROVENANCE.md',OUT/'PROVENANCE.md')
print('Packaged',len(metadata),'bundled dependency notices, MIT, OFL and display provenance.')
