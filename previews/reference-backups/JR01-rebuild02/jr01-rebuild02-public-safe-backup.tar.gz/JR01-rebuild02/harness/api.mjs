function blocked(name){globalThis.__JR01_OFFLINE__?.blockedOperations.push(name);const e=new Error(`Offline display: ${name} is unavailable`);e.code='JR01_OPERATION_BLOCKED';return Promise.reject(e);}
const config={demo_mode:true,appliance_mode:false,ha_ingress:false,unit_system:'metric'};
export const api=new Proxy(Object.freeze({getConfig:()=>Promise.resolve({...config})}),{get(target,key){return Object.hasOwn(target,key)?target[key]:()=>blocked(String(key));}});
export function getAccessToken(){return null;}
export function setAccessToken(){} // no credential storage
export function setRefreshToken(){}
export function setOnAuthRequired(){}
export function enableTokenPersistence(){}
export function bootstrapSession(){return blocked('bootstrapSession');}
