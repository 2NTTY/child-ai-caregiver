import data from '../fixtures/journal.json' with {type:'json'};
export function getMockData(childId){return structuredClone(data[childId===2?'2':'1']);}
