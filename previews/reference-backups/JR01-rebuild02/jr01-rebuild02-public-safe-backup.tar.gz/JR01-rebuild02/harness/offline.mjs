export function installOfflineGuard(target){
 const audit={candidate:'JR01-rebuild02',blockedTransports:[],blockedOperations:[]};
 const blocked=kind=>{audit.blockedTransports.push(kind);const e=new Error(`Network disabled in offline display: ${kind}`);e.code='JR01_NETWORK_BLOCKED';return e;};
 target.fetch=()=>Promise.reject(blocked('fetch'));
 for(const name of ['XMLHttpRequest','WebSocket'])target[name]=class{constructor(){throw blocked(name);}};
 // Original App unconditionally creates SSE; remain CLOSED, never connect/emit.
 target.EventSource=class{static CONNECTING=0;static OPEN=1;static CLOSED=2;CONNECTING=0;OPEN=1;CLOSED=2;readyState=2;withCredentials=false;constructor(url){this.url=String(url);blocked('EventSource');}close(){this.readyState=2;}addEventListener(){}removeEventListener(){}};
 if(target.navigator){Object.defineProperty(target.navigator,'sendBeacon',{configurable:true,value:()=>{blocked('sendBeacon');return false;}});Object.defineProperty(target.navigator,'wakeLock',{configurable:true,value:undefined});}
 target.__JR01_OFFLINE__=audit;return audit;
}
