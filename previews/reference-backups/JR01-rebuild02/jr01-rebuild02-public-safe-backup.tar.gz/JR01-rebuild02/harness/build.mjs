import path from 'node:path';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {build} from '../upstream/frontend/node_modules/vite/dist/node/index.js';
import react from '../upstream/frontend/node_modules/@vitejs/plugin-react/dist/index.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const front=path.join(root,'upstream/frontend');
const runtime=path.join(root,'runtime');
const aliases=new Map([
  [path.join(front,'src/api.js'),path.join(root,'harness/api.mjs')],
  [path.join(front,'src/utils/mockData.js'),path.join(root,'harness/mock-data.mjs')],
]);
await mkdir(runtime,{recursive:true});
const original=await readFile(path.join(front,'index.html'),'utf8');
const fontLinks=/<link rel="preconnect"[^>]*>\s*<link rel="preconnect"[^>]*>\s*<link\s+href="https:\/\/fonts.googleapis.com\/[^>]+>/;
if(!fontLinks.test(original))throw new Error('Pinned index font links changed');
const csp="default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src data:; font-src 'self'; connect-src 'none'; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'none'";
const transformed=original.replace(fontLinks,'<link rel="stylesheet" href="./local-fonts.css" />')
  .replace('<title>','<meta http-equiv="Content-Security-Policy" content="'+csp+'" />\n    <meta name="referrer" content="no-referrer" />\n    <title>')
  .replace('src="/src/main.jsx"','src="../harness/bootstrap.mjs"');
await writeFile(path.join(runtime,'index.html'),transformed);
const faces=[
  ...[300,500,600,700].map(weight=>({family:'DM Sans',style:'normal',weight,url:'../fonts/ofl/dmsans/DMSans[opsz,wght].ttf'})),
  {family:'DM Sans',style:'italic',weight:400,url:'../fonts/ofl/dmsans/DMSans-Italic[opsz,wght].ttf'},
  ...[400,500].map(weight=>({family:'JetBrains Mono',style:'normal',weight,url:'../fonts/ofl/jetbrainsmono/JetBrainsMono[wght].ttf'})),
];
await writeFile(path.join(runtime,'local-fonts.css'),faces.map(f=>`@font-face{font-family:"${f.family}";font-style:${f.style};font-weight:${f.weight};font-display:swap;src:url("${f.url}") format("truetype");}`).join('\n')+'\n');

const boundary={
  name:'jr01-rebuild02-offline-boundary',enforce:'pre',
  resolveId(source,importer){
    if(!importer || !source.startsWith('.'))return null;
    let resolved=path.resolve(path.dirname(importer.split('?')[0]),source);
    if(!path.extname(resolved))resolved+='.js';
    return aliases.get(resolved)||null;
  },
  transform(_code,id){
    if(aliases.has(id.split('?')[0]))throw new Error('Original transport/generator escaped build boundary: '+id);
  },
  async generateBundle(){
    const ids=[...this.getModuleIds()].sort();
    if(ids.some(id=>aliases.has(id.split('?')[0])))throw new Error('Forbidden original module in output graph');
    for(const destination of aliases.values())if(!ids.includes(destination))throw new Error('Missing expected adapter '+destination);
    const graph={source_commit:'bcc0513567c2fba7c935bd61886ce998a2bf1fab',aliases:[...aliases].map(([from,to])=>({from:path.relative(root,from),to:path.relative(root,to)})),module_ids:ids.map(id=>id.startsWith(root)?path.relative(root,id):id)};
    await writeFile(path.join(root,'evidence/module-graph.json'),JSON.stringify(graph,null,2)+'\n');
  },
};
await build({configFile:false,root:runtime,publicDir:false,base:'./',plugins:[boundary,react()],
  // React plugin deduplication resolves from the runtime root. Point it to the
  // immutable lock's installation instead of another project's React copy.
  resolve:{alias:{react:path.join(front,'node_modules/react'),'react-dom':path.join(front,'node_modules/react-dom')}},
  build:{target:'es2022',outDir:path.join(root,'public'),emptyOutDir:true,modulePreload:false,sourcemap:false},
});
