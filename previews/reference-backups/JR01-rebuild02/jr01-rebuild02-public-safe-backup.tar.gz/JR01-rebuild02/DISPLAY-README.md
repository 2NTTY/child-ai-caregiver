# JR01-rebuild02 offline Journal design draft

NEW REBUILD following loss of the original JR01 archive. Not restored original bytes or the old seal. Unpublished independent BabyTracker v1.13.0 reference, source commit bcc0513567c2fba7c935bd61886ce998a2bf1fab.

Serve this folder statically with no API. Initial Overview is intentionally original; choose **Journal** using desktop tabs or mobile dropdown. Emma has 3 original demo notes, Liam 2. Milestones and Medications remain empty, as in upstream demo. Writes/backend calls are disabled, storage memory-only. Do not use real data or upload files.

See [PROVENANCE.md](PROVENANCE.md), FIXTURE-PROVENANCE.json and licenses. Journal.png was not used. Browser/visual/accessibility acceptance is pending. This directory is not a published website.
