# JR01-rebuild02: new independent Journal draft

**The original archive was lost.** This is a new rebuild made after explicit instruction to recreate the pinned source. It is not restored original bytes, does not reuse the former archive seal, and does not inherit any previous test or browser acceptance. The old JR01 FILES.json digest is a historical reference only; the new archive has its own file inventory and checksum. No previous browser verification existed.

## Source and license

[mbentancour/babytracker](https://github.com/mbentancour/babytracker/tree/bcc0513567c2fba7c935bd61886ce998a2bf1fab), commit **bcc0513567c2fba7c935bd61886ce998a2bf1fab**, root config **v1.13.0**. The upstream frontend package is named baby-buddy-dashboard, version 1.0.0; that is not the release number.

Copyright (c) 2026 Martin Bentancour. Complete [MIT license](licenses/BabyTracker-MIT.txt) retained. Independent design reference, not an official release or endorsement.

- [NotesTab.jsx](https://github.com/mbentancour/babytracker/blob/bcc0513567c2fba7c935bd61886ce998a2bf1fab/frontend/src/tabs/NotesTab.jsx): Git blob `329ee9af2436382c37d17905b50308419dc7342d`.
- [App.jsx](https://github.com/mbentancour/babytracker/blob/bcc0513567c2fba7c935bd61886ce998a2bf1fab/frontend/src/App.jsx): `b4433bb77e32b72fd704752d8ff2d777195a308c`.
- [styles.css](https://github.com/mbentancour/babytracker/blob/bcc0513567c2fba7c935bd61886ce998a2bf1fab/frontend/src/styles.css): `88e2c40c3e6887f7cadf297c4773d3695d652301`.
- [mockData.js](https://github.com/mbentancour/babytracker/blob/bcc0513567c2fba7c935bd61886ce998a2bf1fab/frontend/src/utils/mockData.js): `737c9dd0257f7d48431035d45adaf5f0e0506fe0`.
- [useBabyData.js](https://github.com/mbentancour/babytracker/blob/bcc0513567c2fba7c935bd61886ce998a2bf1fab/frontend/src/hooks/useBabyData.js): `68afb9798373f21d3fb07ac233565ec4c397bd92`.

All 96 frontend files plus root LICENSE/README/config were freshly retrieved and verified against Git blobs. Original App/NotesTab/styles/components/hooks/translations are unmodified. The full app initially shows Overview; use original navigation to enter Journal. No reconstructed UI, screenshot, auto-click, or added record is used.

## Demo and isolation

Original synthetic generator executes in a no-I/O VM after removing only its export keyword. New reproducible fixture parameters: **2026-11-11T23:30:00.000Z**, UTC, en-US, mulberry32 seed **0x4a523032**; generate Emma first, then Liam. These differ from the former draft on purpose and are capture parameters, not screenshot evidence. Details in FIXTURE-PROVENANCE.json.

Emma retains the original three notes and Liam two. Upstream demo does not populate milestones, medications or tags. Those empty sections remain empty; no synthetic filler was added. No real household data, photo, account, credential, backend or model is used. **Journal.png is absent and unused** because its version is not established.

Build aliases replace only api.js and mockData.js. Original transport/generator modules are absent from the build graph. API permits only an in-memory demo config; all other API methods reject. fetch/XHR/WebSocket/beacon are blocked. App's unconditional EventSource is an inert CLOSED object, never a connection/event producer. CSP disables connect/form/object/frame/base; images are restricted to data URLs.

Before App loads, localStorage and sessionStorage become fresh memory-only stores: English, dark theme, metric. Existing origin data is not read and preview changes do not persist. Original controls remain but writes are intentionally unavailable. Do not enter real data or select real files.

Original Google Fonts HTTP requests are replaced with locally pinned same-family DM Sans/JetBrains Mono bytes from google/fonts commit `c30b221beb0c1da59d563feb91ec8656a1fa972a`, with complete OFL. This does not establish historical screenshot font bytes. Runtime dependencies use the exact upstream package-lock; all bundled notices are in licenses/DEPENDENCIES.json.

## Acceptance boundary

New source checks, production build, fixture/API/transport/storage tests, static artifact checks, original frontend unit suite and bounded jsdom full-App Journal test are recorded separately in this rebuild. Simulated DOM is not browser validation.

Browser/screenshot/layout/font-selection/real browser egress/accessibility checks remain for the parent owner's stage. No browser, tsc, Expo export, PR, merge, upload or site publication is performed by this rebuilding task. This local draft must not be presented as a browser-accepted candidate.
